import { useState } from 'react';
import { useApp } from '../store';
import { fmt } from '../lib/format';
import OrderCard from './OrderCard';
import Icon from '../components/Icon';
import CatBadge from '../components/CatBadge';
import ProductArt from '../components/ProductArt';
import { categories } from '../data/demo';

// المتجر يرى ويعدّل بيانات متجره فقط (shopId الخاص بالحساب).
export function MerchantOrders() {
  const { orders, shopId, setOrderStatus } = useApp();
  const mine = orders.filter((o) => o.shopId === shopId);
  if (mine.length === 0)
    return (
      <div className="empty">
        <div className="big"><Icon name="empty" size={46} /></div>لا توجد طلبات لمتجرك بعد.
        <div className="small">أنشئ طلباً من حساب «زبون» لتراه هنا.</div>
      </div>
    );
  return (
    <>
      {mine.map((o) => (
        <OrderCard
          key={o.id}
          order={o}
          showCustomer
          actions={
            <>
              {o.status === 'new' && (
                <>
                  <button className="btn sm" onClick={() => setOrderStatus(o.id, 'accepted')}>قبول</button>
                  <button className="btn danger sm" onClick={() => setOrderStatus(o.id, 'cancelled')}>رفض</button>
                </>
              )}
              {o.status === 'accepted' && (
                <button className="btn sm" onClick={() => setOrderStatus(o.id, 'preparing')}>بدء التجهيز</button>
              )}
              {o.status === 'preparing' && <span className="muted small">بانتظار المندوب…</span>}
            </>
          }
        />
      ))}
    </>
  );
}

export function MerchantProducts() {
  const { products, shops, shopId, updateProduct, addProduct, deleteProduct, updateShop } = useApp();
  const shop = shops.find((s) => s.id === shopId);
  const list = products.filter((p) => p.shopId === shopId);
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('10');

  const add = () => {
    const pr = Number(price);
    if (!name.trim() || !(pr > 0)) return;
    addProduct({
      shopId,
      categoryId: shop?.categoryId ?? categories[0].id,
      name: name.trim(),
      price: Math.round(pr),
      stock: Math.max(0, Number(stock) || 0),
      art: 'box',
      tone: '#fde7d3',
      desc: '',
    });
    setName('');
    setPrice('');
  };

  return (
    <>
      {shop && (
        <div className="card row between">
          <div>
            <div className="row"><CatBadge categoryId={shop.categoryId} size={40} /><div className="bold">{shop.name}</div></div>
            <div className="muted small">{shop.area}</div>
          </div>
          <button className={`btn sm ${shop.open ? '' : 'danger'}`} onClick={() => updateShop(shop.id, { open: !shop.open })}>
            <Icon name={shop.open ? 'check' : 'close'} size={14} /> {shop.open ? 'مفتوح' : 'مغلق'}
          </button>
        </div>
      )}

      <div className="h2">المنتجات</div>
      {list.map((p) => (
        <div key={p.id} className="card">
          <div className="row between">
            <div className="row"><div style={{ width: 40 }}><ProductArt kind={p.art} tone={p.tone} rounded={10} /></div><div className="bold">{p.name}</div></div>
            <button className="btn danger sm" onClick={() => window.confirm('حذف المنتج؟') && deleteProduct(p.id)}>حذف</button>
          </div>
          <div className="row" style={{ marginTop: 8 }}>
            <label className="field grow" style={{ margin: 0 }}>
              <span>السعر (د.ع)</span>
              <input
                type="number"
                inputMode="numeric"
                value={p.price}
                onChange={(e) => updateProduct(p.id, { price: Math.max(0, Number(e.target.value) || 0) })}
              />
            </label>
            <label className="field grow" style={{ margin: 0 }}>
              <span>المخزون</span>
              <input
                type="number"
                inputMode="numeric"
                value={p.stock}
                onChange={(e) => updateProduct(p.id, { stock: Math.max(0, Number(e.target.value) || 0) })}
              />
            </label>
          </div>
        </div>
      ))}

      <div className="card">
        <div className="bold" style={{ marginBottom: 8 }}>إضافة منتج</div>
        <div className="row">
          <label className="field grow">
            <span>الاسم</span>
            <input value={name} onChange={(e) => setName(e.target.value)} />
          </label>
        </div>
        <div className="row">
          <label className="field grow">
            <span>السعر ({fmt(0).replace('0 ', '')})</span>
            <input type="number" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value)} />
          </label>
          <label className="field grow">
            <span>المخزون</span>
            <input type="number" inputMode="numeric" value={stock} onChange={(e) => setStock(e.target.value)} />
          </label>
        </div>
        <div className="muted small" style={{ marginBottom: 8 }}>رفع صور المنتجات يأتي في المرحلة الثانية (Supabase Storage).</div>
        <button className="btn block" onClick={add}>إضافة</button>
      </div>
    </>
  );
}
