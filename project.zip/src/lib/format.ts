import type { OrderStatus } from '../types';

export const fmt = (n: number): string =>
  `${Math.round(n).toLocaleString('en-US')} د.ع`;

export const STATUS_LABEL: Record<OrderStatus, string> = {
  new: 'جديد',
  accepted: 'مقبول',
  preparing: 'قيد التجهيز',
  on_the_way: 'المندوب بالطريق',
  delivered: 'تم التسليم',
  cancelled: 'ملغي',
};

export const STATUS_FLOW: OrderStatus[] = [
  'new',
  'accepted',
  'preparing',
  'on_the_way',
  'delivered',
];

export const timeStr = (t: number): string =>
  new Date(t).toLocaleString('ar-IQ', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' });

export const mapLink = (lat?: number, lng?: number, address?: string): string =>
  lat !== undefined && lng !== undefined
    ? `https://www.google.com/maps?q=${lat},${lng}`
    : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent((address ?? '') + ' البصرة')}`;
