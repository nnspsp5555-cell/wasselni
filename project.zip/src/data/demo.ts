// ============================================================
// بيانات تجريبية لتطبيق وصّلني.
// كل الأسماء والأسعار هنا توضيحية فقط وليست أسعاراً حقيقية من متاجر البصرة.
// لتعديل المنتجات: غيّر المصفوفة `products` أدناه (art = نوع الرسم التوضيحي).
// لتفعيل قسم جديد لاحقاً: غيّر enabled إلى true وأضف له متاجر ومنتجات.
// ============================================================
import type { Category, Courier, Offer, Product, Shop } from '../types';

export const CITIES = ['البصرة'];

export const categories: Category[] = [
  // ---- الأقسام المتاحة حالياً ----
  { id: 'kitchen', name: 'المواعين وأدوات المطبخ', short: 'المواعين', icon: 'pot', tint: '#e8590c', tintBg: '#fff0e6', enabled: true },
  { id: 'electronics', name: 'الإلكترونيات والموبايلات', short: 'الإلكترونيات', icon: 'phone', tint: '#1c64f2', tintBg: '#e8f0ff', enabled: true },
  // ---- أقسام قادمة (جاري العمل) ----
  { id: 'food', name: 'المطاعم والأكل', short: 'المطاعم', icon: 'burger', tint: '#d9480f', tintBg: '#ffeee6', enabled: false },
  { id: 'clothes', name: 'الملابس والأحذية', short: 'الملابس', icon: 'shirt', tint: '#7048e8', tintBg: '#f1ecff', enabled: false },
  { id: 'furniture', name: 'الأثاث ومستلزمات المنزل', short: 'الأثاث', icon: 'sofa', tint: '#0b7285', tintBg: '#e3f6f9', enabled: false },
  { id: 'perfume', name: 'العطور والإكسسوارات', short: 'العطور', icon: 'perfume', tint: '#c2255c', tintBg: '#ffe8f1', enabled: false },
  { id: 'grocery', name: 'البقالة والمواد الغذائية', short: 'البقالة', icon: 'basket', tint: '#2b8a3e', tintBg: '#e6f7ea', enabled: false },
  { id: 'used', name: 'سوق المستعمل', short: 'المستعمل', icon: 'recycle', tint: '#5c7cfa', tintBg: '#edf0ff', enabled: false },
];

export const shops: Shop[] = [
  { id: 's1', name: 'مواعين الرافدين', categoryId: 'kitchen', rating: 4.7, etaMin: 40, deliveryFee: 3000, area: 'العشار', open: true, phone: '07700000001' },
  { id: 's2', name: 'بيت الطبخ', categoryId: 'kitchen', rating: 4.5, etaMin: 45, deliveryFee: 3000, area: 'الجزائر', open: true, phone: '07700000002' },
  { id: 's3', name: 'متجر البصرة للأجهزة', categoryId: 'electronics', rating: 4.7, etaMin: 35, deliveryFee: 5000, area: 'العشار', open: true, phone: '07700000003' },
  { id: 's4', name: 'عالم الموبايلات', categoryId: 'electronics', rating: 4.6, etaMin: 40, deliveryFee: 4000, area: 'البراضعية', open: true, phone: '07700000004' },
];

export const products: Product[] = [
  // ---------------- المواعين وأدوات المطبخ ----------------
  { id: 'k1', shopId: 's1', categoryId: 'kitchen', name: 'طقم قدور ستانلس 6 قطع', price: 75000, stock: 12, art: 'pot', tone: '#fde7d3', desc: 'طقم قدور ستانلس ستيل بأغطية زجاجية، مناسب لجميع أنواع المواقد.', specs: ['المادة: ستانلس ستيل', 'عدد القطع: 6', 'الأغطية: زجاج'], badge: 'الأكثر طلباً' },
  { id: 'k2', shopId: 's2', categoryId: 'kitchen', name: 'مقلاة غير لاصقة 28 سم', price: 22000, stock: 25, art: 'pan', tone: '#e6ecf5', desc: 'مقلاة بطبقة غير لاصقة ومقبض مقاوم للحرارة.', specs: ['القطر: 28 سم', 'الطبقة: غير لاصقة'] },
  { id: 'k3', shopId: 's1', categoryId: 'kitchen', name: 'طقم صحون 24 قطعة', price: 48000, stock: 15, art: 'plates', tone: '#e8f4ee', desc: 'طقم صحون سيراميك لـ 6 أشخاص.', specs: ['عدد القطع: 24', 'المادة: سيراميك', 'يكفي: 6 أشخاص'], badge: 'جديد' },
  { id: 'k4', shopId: 's1', categoryId: 'kitchen', name: 'طقم ملاعق وشوك 24 قطعة', price: 18000, stock: 30, art: 'cutlery', tone: '#eef0f4', desc: 'ملاعق وشوك وسكاكين ستانلس لامعة.', specs: ['عدد القطع: 24', 'المادة: ستانلس'] },
  { id: 'k5', shopId: 's2', categoryId: 'kitchen', name: 'غلاية كهربائية 1.7 لتر', price: 25000, stock: 20, art: 'kettle', tone: '#fbe4e4', desc: 'غلاية كهربائية بإطفاء تلقائي.', specs: ['السعة: 1.7 لتر', 'إطفاء تلقائي'] },
  { id: 'k6', shopId: 's2', categoryId: 'kitchen', name: 'خلاط كهربائي', price: 45000, stock: 10, art: 'blender', tone: '#efe6f7', desc: 'خلاط بجرة زجاجية وثلاث سرعات.', specs: ['الجرة: زجاج 1.5 لتر', 'السرعات: 3'] },
  { id: 'k7', shopId: 's2', categoryId: 'kitchen', name: 'قدر ضغط 6 لتر', price: 55000, stock: 8, art: 'pot', tone: '#fff0d6', desc: 'قدر ضغط ألمنيوم بصمام أمان.', specs: ['السعة: 6 لتر', 'صمام أمان'] },
  { id: 'k8', shopId: 's1', categoryId: 'kitchen', name: 'طقم استكانات شاي 12 قطعة', price: 12000, stock: 40, art: 'teaset', tone: '#fde7d3', desc: 'استكانات وصحون شاي على الطريقة العراقية.', specs: ['عدد القطع: 12'] },

  // ---------------- الإلكترونيات والموبايلات ----------------
  { id: 'e1', shopId: 's3', categoryId: 'electronics', name: 'هاتف ذكي 256GB', price: 450000, stock: 6, art: 'phone', tone: '#e3ebf7', desc: 'هاتف ذكي بشاشة كبيرة وكاميرا ثلاثية (منتج توضيحي).', specs: ['السعة: 256GB', 'الذاكرة: 8GB', 'الشاشة: 6.7 إنش'], badge: 'جديد' },
  { id: 'e2', shopId: 's4', categoryId: 'electronics', name: 'هاتف اقتصادي 128GB', price: 220000, stock: 14, art: 'phone', tone: '#e8f4ee', desc: 'هاتف اقتصادي ببطارية كبيرة (منتج توضيحي).', specs: ['السعة: 128GB', 'البطارية: 5000mAh'] },
  { id: 'e3', shopId: 's3', categoryId: 'electronics', name: 'سماعات بلوتوث لاسلكية', price: 35000, stock: 30, art: 'earbuds', tone: '#fde7d3', desc: 'سماعات أذن لاسلكية مع علبة شحن.', specs: ['الاتصال: بلوتوث 5.3', 'التشغيل: حتى 20 ساعة'], badge: 'الأكثر طلباً' },
  { id: 'e4', shopId: 's4', categoryId: 'electronics', name: 'شاحن سريع 25 واط', price: 15000, stock: 50, art: 'charger', tone: '#eef0f4', desc: 'شاحن جداري سريع بمنفذ USB-C.', specs: ['القدرة: 25 واط', 'المنفذ: USB-C'] },
  { id: 'e5', shopId: 's4', categoryId: 'electronics', name: 'باور بانك 20000mAh', price: 30000, stock: 22, art: 'powerbank', tone: '#e6ecf5', desc: 'بطارية متنقلة بمنفذين.', specs: ['السعة: 20000mAh', 'المنافذ: 2'] },
  { id: 'e6', shopId: 's3', categoryId: 'electronics', name: 'ساعة ذكية', price: 60000, stock: 18, art: 'watch', tone: '#efe6f7', desc: 'ساعة ذكية بمتابعة النشاط والإشعارات.', specs: ['الشاشة: AMOLED', 'مقاومة للرذاذ'] },
  { id: 'e7', shopId: 's3', categoryId: 'electronics', name: 'مكبر صوت بلوتوث', price: 40000, stock: 16, art: 'speaker', tone: '#fbe4e4', desc: 'مكبر صوت محمول بصوت قوي.', specs: ['الاتصال: بلوتوث', 'التشغيل: 8 ساعات'] },
  { id: 'e8', shopId: 's4', categoryId: 'electronics', name: 'كيبل USB-C بطول 1 متر', price: 5000, stock: 80, art: 'cable', tone: '#fff0d6', desc: 'كيبل شحن ونقل بيانات مقوّى.', specs: ['الطول: 1 متر', 'USB-C'] },
];

export const offers: Offer[] = [
  { id: 'o1', title: 'خصم 15% من مواعين الرافدين', desc: 'عرض توضيحي على كل المنتجات', shopId: 's1', discountPct: 15, active: true },
  { id: 'o2', title: 'خصم 10% متجر البصرة للأجهزة', desc: 'عرض توضيحي للأجهزة', shopId: 's3', discountPct: 10, active: true },
  { id: 'o3', title: 'خصم 5% عالم الموبايلات', desc: 'عرض متوقف حالياً', shopId: 's4', discountPct: 5, active: false },
];

export const couriers: Courier[] = [
  { id: 'c1', name: 'علي الموسوي', phone: '07800000001' },
  { id: 'c2', name: 'حيدر الساعدي', phone: '07800000002' },
];

export const demoCustomers = [{ id: 'u1', name: 'زبون تجريبي', phone: '07900000001' }];
