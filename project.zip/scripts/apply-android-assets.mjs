// يُشغَّل تلقائياً بعد `npx cap sync` (hook: capacitor:sync:after في package.json).
// ينسخ أيقونات وصّلني إلى مشروع Android الذي ولّده Capacitor.
import fs from 'node:fs';
import path from 'node:path';

const res = path.join('android', 'app', 'src', 'main', 'res');
const src = path.join('resources', 'android');

if (!fs.existsSync(res)) {
  console.log('[wasselni] مجلد android غير موجود بعد، تخطي الأيقونات.');
  process.exit(0);
}
if (!fs.existsSync(src)) {
  console.log('[wasselni] resources/android غير موجود، تخطي الأيقونات.');
  process.exit(0);
}

// نستخدم أيقونات PNG القديمة (غير التكيفية) كي تظهر أيقونتنا كما هي.
fs.rmSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true, force: true });

let copied = 0;
for (const dir of fs.readdirSync(src)) {
  const from = path.join(src, dir);
  if (!fs.statSync(from).isDirectory()) continue;
  const to = path.join(res, dir);
  fs.mkdirSync(to, { recursive: true });
  for (const f of fs.readdirSync(from)) {
    fs.copyFileSync(path.join(from, f), path.join(to, f));
    copied++;
  }
}
console.log(`[wasselni] تم نسخ ${copied} ملف أيقونة إلى android.`);
