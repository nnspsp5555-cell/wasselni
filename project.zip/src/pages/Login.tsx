import { useApp } from '../store';
import { isSupabaseConfigured } from '../lib/supabase';
import { shops, couriers } from '../data/demo';
import type { Role } from '../types';
import Icon, { type IconName } from '../components/Icon';
import { LogoMark } from '../components/Logo';

const ROLES: { role: Role; icon: IconName; title: string; desc: string }[] = [
  { role: 'customer', icon: 'bag', title: 'زبون', desc: 'تصفح المتاجر واطلب' },
  { role: 'merchant', icon: 'store', title: 'متجر', desc: 'إدارة المنتجات والطلبات' },
  { role: 'courier', icon: 'truck', title: 'مندوب', desc: 'مهام التوصيل' },
  { role: 'admin', icon: 'settings', title: 'مدير', desc: 'لوحة الإدارة' },
];

export default function Login() {
  const { login, seedDemoOrders } = useApp();
  return (
    <div className="login">
      <div style={{ textAlign: 'center', marginBottom: 14 }}>
        <div style={{ display: 'inline-block', borderRadius: 24, boxShadow: '0 6px 20px rgba(0,0,0,.25)', overflow: 'hidden' }}>
          <LogoMark size={96} />
        </div>
        <h1 style={{ marginTop: 10 }}>وصّلني</h1>
        <div style={{ fontWeight: 700, color: '#ffe3cf' }}>Wasselni</div>
        <div style={{ opacity: 0.95, marginTop: 6 }}>كل احتياجاتك .. من البصرة لبيتك</div>
      </div>

      <div className="demo-note">
        <Icon name="warn" size={16} /> <b>نسخة تجريبية:</b> الدخول هنا لاختيار نوع الحساب فقط، والبيانات تُحفظ على هذا الجهاز فقط ولا تُرسل إلى
        الإنترنت.
        {isSupabaseConfigured
          ? ' (تم ضبط مفاتيح Supabase، لكن ربط الحسابات الحقيقية يأتي في المرحلة الثانية.)'
          : ' (مفاتيح Supabase غير مضبوطة.)'}
      </div>

      {ROLES.map((r) => (
        <button
          key={r.role}
          className="role-btn"
          onClick={() =>
            login(r.role, {
              shopId: r.role === 'merchant' ? shops[0].id : undefined,
              courierId: r.role === 'courier' ? couriers[0].id : undefined,
            })
          }
        >
          <span className="role-ic"><Icon name={r.icon} size={26} /></span>
          <span>
            <b>{r.title}</b>
            <div className="muted">{r.desc}</div>
          </span>
        </button>
      ))}
      <button className="seed-link" onClick={seedDemoOrders}>
        إضافة طلبات تجريبية لمعاينة شاشات المتجر والمندوب والمدير
      </button>
    </div>
  );
}
