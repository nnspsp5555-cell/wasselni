// مجموعة أيقونات خطية موحّدة (SVG) لتطبيق وصّلني، بدل الإيموجي.
// الأيقونات ترث لون النص (currentColor) وتتغير مع الحالة.

export type IconName =
  | 'home' | 'cart' | 'orders' | 'user' | 'store' | 'truck' | 'chart' | 'tag' | 'inbox'
  | 'pot' | 'phone' | 'burger' | 'shirt' | 'sofa' | 'perfume' | 'basket' | 'recycle'
  | 'lock' | 'search' | 'pin' | 'call' | 'map' | 'star' | 'flame' | 'bell' | 'check'
  | 'close' | 'chevron' | 'warn' | 'cash' | 'box' | 'grid' | 'bag' | 'settings' | 'empty';

const P: Record<IconName, JSX.Element> = {
  home: (
    <>
      <path d="M3 11.5 12 4l9 7.5" />
      <path d="M5.5 10v9.5h13V10" />
      <path d="M10 19.5v-5h4v5" />
    </>
  ),
  cart: (
    <>
      <circle cx="9" cy="19.5" r="1.4" />
      <circle cx="17.5" cy="19.5" r="1.4" />
      <path d="M2.5 3.5H5l2.4 11.2a1 1 0 0 0 1 .8h8.6a1 1 0 0 0 1-.8L19.5 7H6" />
    </>
  ),
  orders: (
    <>
      <path d="M6 3h12v18l-3-2-3 2-3-2-3 2z" />
      <path d="M9.5 8h5M9.5 12h5M9.5 16h3" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="3.6" />
      <path d="M4.5 20.5c0-3.6 3.4-5.8 7.5-5.8s7.5 2.2 7.5 5.8" />
    </>
  ),
  store: (
    <>
      <path d="M3.5 9.5 5 4h14l1.5 5.5" />
      <path d="M3.5 9.5a2.8 2.8 0 0 0 5.5 0 2.8 2.8 0 0 0 6 0 2.8 2.8 0 0 0 5.5 0" />
      <path d="M5 12.5V20h14v-7.5" />
      <path d="M10 20v-4.5h4V20" />
    </>
  ),
  truck: (
    <>
      <path d="M2 6.5h11.5V16H2z" />
      <path d="M13.5 10h4l3 3v3h-7" />
      <circle cx="6.5" cy="17.5" r="1.9" />
      <circle cx="17" cy="17.5" r="1.9" />
    </>
  ),
  chart: (
    <>
      <path d="M4 20V11M10 20V4M16 20v-6M21.5 20h-19" />
    </>
  ),
  tag: (
    <>
      <path d="M20.5 12.5 12.5 20.5 3.5 11.5V3.5h8z" />
      <circle cx="7.8" cy="7.8" r="1.3" />
    </>
  ),
  inbox: (
    <>
      <path d="M21.5 12.5h-5.5l-1.8 2.8H9.8L8 12.5H2.5" />
      <path d="M5.6 5.6 2.5 12.5V18a2 2 0 0 0 2 2h15a2 2 0 0 0 2-2v-5.5l-3.1-6.9A2 2 0 0 0 16.6 4.5H7.4a2 2 0 0 0-1.8 1.1z" />
    </>
  ),
  pot: (
    <>
      <path d="M4.5 10.5h15v7a3 3 0 0 1-3 3h-9a3 3 0 0 1-3-3z" />
      <path d="M2 11.5h2.5M19.5 11.5H22" />
      <path d="M6.5 10.5c.4-3 2.6-4.8 5.5-4.8s5.1 1.8 5.5 4.8" />
      <path d="M12 3.5v2.2" />
    </>
  ),
  phone: (
    <>
      <rect x="6.5" y="2.5" width="11" height="19" rx="2.8" />
      <path d="M10.8 18.5h2.4" />
    </>
  ),
  burger: (
    <>
      <path d="M4 11a8 6 0 0 1 16 0z" />
      <path d="M3 14.5c2 1.5 3 1.5 4.5 0s3-1.5 4.5 0 3 1.5 4.5 0 2.5-1.5 4.5 0" />
      <path d="M5 17.5v.5a2.5 2.5 0 0 0 2.5 2.5h9a2.5 2.5 0 0 0 2.5-2.5v-.5z" />
    </>
  ),
  shirt: (
    <>
      <path d="M8.5 3.5 3 6.5l2.2 4 2.8-1.2V20.5h8V9.3l2.8 1.2 2.2-4-5.5-3a3.6 3.6 0 0 1-7 0z" />
    </>
  ),
  sofa: (
    <>
      <path d="M5.5 11V8.5a3 3 0 0 1 3-3h7a3 3 0 0 1 3 3V11" />
      <path d="M3 13.5a2 2 0 0 1 4 0V15h10v-1.5a2 2 0 0 1 4 0V19H3z" />
      <path d="M5.5 19v1.5M18.5 19v1.5" />
    </>
  ),
  perfume: (
    <>
      <rect x="6" y="10" width="12" height="11" rx="2.5" />
      <path d="M9.5 10V7h5v3" />
      <path d="M10.5 7V4.5h3V7" />
      <path d="M15 5.5h2.5" />
    </>
  ),
  basket: (
    <>
      <path d="M5 9.5 6.7 19.5a1 1 0 0 0 1 .8h8.6a1 1 0 0 0 1-.8L19 9.5" />
      <path d="M2.8 9.5h18.4" />
      <path d="m8.5 9.5 3.5-5.5 3.5 5.5" />
    </>
  ),
  recycle: (
    <>
      <path d="m17 3 3.5 3.5L17 10" />
      <path d="M3.5 11V9.5a3 3 0 0 1 3-3h14" />
      <path d="m7 21-3.5-3.5L7 14" />
      <path d="M20.5 13v1.5a3 3 0 0 1-3 3h-14" />
    </>
  ),
  lock: (
    <>
      <rect x="5" y="10.5" width="14" height="10" rx="2.2" />
      <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="6.5" />
      <path d="m20.5 20.5-4.7-4.7" />
    </>
  ),
  pin: (
    <>
      <path d="M12 21.5s6.8-6 6.8-11.7a6.8 6.8 0 0 0-13.6 0C5.2 15.5 12 21.5 12 21.5z" />
      <circle cx="12" cy="9.8" r="2.4" />
    </>
  ),
  call: (
    <>
      <path d="M5.2 3.5h3.6l1.8 4.6-2.3 1.4a10.5 10.5 0 0 0 4.7 4.7l1.4-2.3 4.6 1.8v3.6a2 2 0 0 1-2.1 2A15.5 15.5 0 0 1 3.2 5.6a2 2 0 0 1 2-2.1z" />
    </>
  ),
  map: (
    <>
      <path d="M9 4 3 6.2V20l6-2.2 6 2.2 6-2.2V4l-6 2.2z" />
      <path d="M9 4v13.8M15 6.2V20" />
    </>
  ),
  star: (
    <path
      d="m12 3.2 2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.5l6-.8z"
      fill="currentColor"
    />
  ),
  flame: (
    <>
      <path d="M12 21.5c3.9 0 6.5-2.8 6.5-6.5 0-2.8-1.8-4.7-3-6.6-.9 1.6-1.8 2.4-2.8 2.6.2-3.6-1-6-3.7-8-.1 3.7-3.5 5.6-3.5 11.1 0 4 2.6 7.4 6.5 7.4z" />
    </>
  ),
  bell: (
    <>
      <path d="M18 16v-5a6 6 0 0 0-12 0v5l-2 2.5h16z" />
      <path d="M10 21a2 2 0 0 0 4 0" />
    </>
  ),
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  chevron: <path d="m15 5.5-6.5 6.5 6.5 6.5" />,
  warn: (
    <>
      <path d="M12 3.5 21.5 20h-19z" />
      <path d="M12 10v4.5M12 17.5v.2" />
    </>
  ),
  cash: (
    <>
      <rect x="2.5" y="6" width="19" height="12" rx="2.2" />
      <circle cx="12" cy="12" r="2.7" />
      <path d="M6 9.5v.1M18 14.5v.1" />
    </>
  ),
  box: (
    <>
      <path d="m21 8-9-5-9 5v8l9 5 9-5z" />
      <path d="m3.3 8 8.7 5 8.7-5M12 13v8" />
    </>
  ),
  grid: (
    <>
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.8" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.8" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.8" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.8" />
    </>
  ),
  bag: (
    <>
      <path d="M5.5 7.5h13l1 13h-15z" />
      <path d="M9 7.5a3 3 0 0 1 6 0" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7" />
    </>
  ),
  empty: (
    <>
      <path d="M3.5 13 6 5h12l2.5 8" />
      <path d="M3.5 13v5.5a1.5 1.5 0 0 0 1.5 1.5h14a1.5 1.5 0 0 0 1.5-1.5V13h-5.5a3 3 0 0 1-6 0z" />
    </>
  ),
};

interface Props {
  name: IconName;
  size?: number;
  stroke?: number;
  className?: string;
}

export default function Icon({ name, size = 22, stroke = 1.7, className }: Props) {
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={stroke}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      style={{ flex: 'none' }}
    >
      {P[name]}
    </svg>
  );
}
