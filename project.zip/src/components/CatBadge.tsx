import { categories } from '../data/demo';
import Icon from './Icon';

/** أيقونة القسم داخل مربع ملوّن (تُستخدم أيضاً كشعار للمتجر حسب قسمه) */
export default function CatBadge({ categoryId, size = 52 }: { categoryId: string; size?: number }) {
  const c = categories.find((x) => x.id === categoryId);
  return (
    <div
      className="emoji"
      style={{ width: size, height: size, background: c?.tintBg ?? 'var(--brand-soft)', color: c?.tint ?? 'var(--brand)' }}
    >
      <Icon name={c?.icon ?? 'store'} size={Math.round(size * 0.5)} />
    </div>
  );
}
