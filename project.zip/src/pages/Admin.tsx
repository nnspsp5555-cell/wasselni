import { useApp } from '../store';
import { categories, couriers, demoCustomers } from '../data/demo';
import { fmt } from '../lib/format';
import OrderCard from './OrderCard';

export function AdminDashboard() {
  const { orders, settings, shops, setCommission } = useApp();
  const delivered = orders.filter((o) => o.status === 'delivered');
  const revenue = delivered.reduce((s, o) => s + o.subtotal - o.discount, 0);
  const commission = Math.round((revenue * settings.commissionPct) / 100);
  const active = orders.filter((o) => !['delivered', 'cancelled'].includes(o.status)).length;

  return (
    <>
      <div className="stats">
        <div className="stat"><span className="muted small">كل الطلبات</span><b>{orders.length}</b></div>
        <div className="stat"><span className="muted small">طلبات نشطة</span><b>{active}</b></div>
        <div className="stat"><span className="muted small">مبيعات مسلّمة</span><b>{fmt(revenue)}</b></div>
        <div className="stat"><span className="muted small">عمولة المنصة</span><b>{fmt(commission)}</b></div>
      </div>

      <div className="card">
        <div className="bold" style={{ marginBottom: 8 }}>الإعدادات</div>
        <label className="field">
          <span>نسبة العمولة (%)</span>
          <input type="number" inputMode="numeric" value={settings.commissionPct} onChange={(e) => setCommission(Number(e.target.value) || 0)} />
        </label>
        <div className="muted small">المدينة: {settings.city} (إضافة مدن جديدة في المرحلة الثانية)</div>
      </div>

      <div className="h2">التصنيفات</div>
      <div className="card row" style={{ flexWrap: 'wrap' }}>
        {categories.map((c) => (
          <span key={c.id} className="tag">{c.icon} {c.name}</span>
        ))}
      </div>

      <div className="h2">المندوبون</div>
      {couriers.map((c) => (
        <div key={c.id} className="card row between">
          <span>🛵 {c.name}</span>
          <a href={`tel:${c.phone}`}>{c.phone}</a>
        </div>
      ))}

      <div className="h2">الزبائن</div>
      {demoCustomers.map((c) => (
        <div key={c.id} className="card row between">
          <span>👤 {c.name}</span>
          <span className="muted">{c.phone}</span>
        </div>
      ))}
      <div className="muted small">عدد المتاجر: {shops.length}</div>
    </>
  );
}

export function AdminOrders() {
  const { orders, setOrderStatus } = useApp();
  if (orders.length === 0)
    return (
      <div className="empty">
        <div className="big">📭</div>لا توجد طلبات
      </div>
    );
  return (
    <>
      {orders.map((o) => (
        <OrderCard
          key={o.id}
          order={o}
          showCustomer
          actions={
            o.status !== 'cancelled' && o.status !== 'delivered' ? (
              <button className="btn danger sm" onClick={() => setOrderStatus(o.id, 'cancelled')}>إلغاء (مدير)</button>
            ) : undefined
          }
        />
      ))}
    </>
  );
}

export function AdminShops() {
  const { shops, offers, updateShop, toggleOffer } = useApp();
  return (
    <>
      <div className="h2">المتاجر</div>
      {shops.map((s) => (
        <div key={s.id} className="card">
          <div className="row between">
            <div className="bold">{s.emoji} {s.name}</div>
            <button className={`btn sm ${s.open ? '' : 'danger'}`} onClick={() => updateShop(s.id, { open: !s.open })}>
              {s.open ? 'مفتوح' : 'مغلق'}
            </button>
          </div>
          <label className="field" style={{ marginTop: 8, marginBottom: 0 }}>
            <span>رسوم التوصيل (د.ع)</span>
            <input
              type="number"
              inputMode="numeric"
              value={s.deliveryFee}
              onChange={(e) => updateShop(s.id, { deliveryFee: Math.max(0, Number(e.target.value) || 0) })}
            />
          </label>
        </div>
      ))}

      <div className="h2">العروض</div>
      {offers.map((o) => (
        <div key={o.id} className="card row between">
          <div>
            <div className="bold">{o.title}</div>
            <div className="muted small">{o.desc}</div>
          </div>
          <button className={`btn sm ${o.active ? '' : 'ghost'}`} onClick={() => toggleOffer(o.id)}>
            {o.active ? 'فعّال' : 'متوقف'}
          </button>
        </div>
      ))}
    </>
  );
}
