import { useEffect, useState } from 'react';
import { LogoFull } from './Logo';

// شاشة بداية داخل التطبيق (حوالي ثانية ونصف) بالشعار الكامل.
export default function Splash({ onDone }: { onDone: () => void }) {
  const [fade, setFade] = useState(false);
  useEffect(() => {
    const a = window.setTimeout(() => setFade(true), 1300);
    const b = window.setTimeout(onDone, 1700);
    return () => {
      window.clearTimeout(a);
      window.clearTimeout(b);
    };
  }, [onDone]);
  return (
    <div className={`splash ${fade ? 'fade' : ''}`}>
      <LogoFull width={260} />
    </div>
  );
}
