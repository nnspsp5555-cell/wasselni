import type { ArtKind } from '../types';

// رسومات توضيحية أصلية (SVG) للمنتجات التجريبية، وليست صور منتجات حقيقية.
const NAVY = '#14233c';
const ORANGE = '#f26a1b';
const STEEL = '#cfd6df';
const STEEL_D = '#9aa6b5';
const WHITE = '#ffffff';

function Shapes({ kind }: { kind: ArtKind }) {
  switch (kind) {
    case 'pot':
      return (
        <g>
          <rect x="30" y="52" width="60" height="36" rx="6" fill={STEEL} stroke={STEEL_D} strokeWidth="2" />
          <path d="M30 52c0-10 12-16 30-16s30 6 30 16z" fill="#e9eef4" stroke={STEEL_D} strokeWidth="2" />
          <circle cx="60" cy="33" r="4" fill={NAVY} />
          <rect x="18" y="58" width="12" height="6" rx="3" fill={NAVY} />
          <rect x="90" y="58" width="12" height="6" rx="3" fill={NAVY} />
        </g>
      );
    case 'pan':
      return (
        <g>
          <ellipse cx="52" cy="62" rx="34" ry="14" fill={NAVY} />
          <ellipse cx="52" cy="58" rx="30" ry="11" fill="#2b3d5a" />
          <rect x="84" y="56" width="30" height="8" rx="4" fill={ORANGE} />
        </g>
      );
    case 'plates':
      return (
        <g>
          <ellipse cx="60" cy="72" rx="38" ry="12" fill={WHITE} stroke={STEEL_D} strokeWidth="2" />
          <ellipse cx="60" cy="62" rx="38" ry="12" fill={WHITE} stroke={STEEL_D} strokeWidth="2" />
          <ellipse cx="60" cy="52" rx="38" ry="12" fill={WHITE} stroke={STEEL_D} strokeWidth="2" />
          <ellipse cx="60" cy="52" rx="24" ry="7" fill="#fde7d3" />
        </g>
      );
    case 'cutlery':
      return (
        <g>
          <rect x="36" y="48" width="6" height="46" rx="3" fill={STEEL_D} />
          <path d="M30 22h18v18c0 6-4 9-9 9s-9-3-9-9z" fill={STEEL} stroke={STEEL_D} strokeWidth="2" />
          <rect x="57" y="22" width="5" height="26" rx="2" fill={STEEL} stroke={STEEL_D} strokeWidth="1.5" />
          <rect x="66" y="22" width="5" height="26" rx="2" fill={STEEL} stroke={STEEL_D} strokeWidth="1.5" />
          <rect x="75" y="22" width="5" height="26" rx="2" fill={STEEL} stroke={STEEL_D} strokeWidth="1.5" />
          <rect x="62" y="46" width="14" height="48" rx="5" fill={STEEL_D} />
        </g>
      );
    case 'kettle':
      return (
        <g>
          <path d="M34 90V56c0-16 11-26 26-26s26 10 26 26v34z" fill={ORANGE} />
          <rect x="28" y="88" width="64" height="8" rx="4" fill={NAVY} />
          <path d="M86 52c14 0 20 8 20 18" fill="none" stroke={NAVY} strokeWidth="6" strokeLinecap="round" />
          <path d="M34 62L18 54" stroke={ORANGE} strokeWidth="7" strokeLinecap="round" />
          <circle cx="60" cy="28" r="5" fill={NAVY} />
        </g>
      );
    case 'blender':
      return (
        <g>
          <path d="M40 24h40l-6 46H46z" fill="#dfe9f5" stroke={STEEL_D} strokeWidth="2" />
          <rect x="38" y="18" width="44" height="8" rx="4" fill={NAVY} />
          <rect x="42" y="70" width="36" height="22" rx="6" fill={NAVY} />
          <circle cx="60" cy="81" r="5" fill={ORANGE} />
          <path d="M50 40l10 12 10-12" fill="none" stroke="#9db4d0" strokeWidth="3" />
        </g>
      );
    case 'teaset':
      return (
        <g>
          <path d="M30 50h28c0 14-6 24-14 24s-14-10-14-24z" fill={WHITE} stroke={STEEL_D} strokeWidth="2" />
          <path d="M58 54c8 0 8 12 0 12" fill="none" stroke={STEEL_D} strokeWidth="3" />
          <ellipse cx="44" cy="80" rx="22" ry="5" fill="#eef1f5" stroke={STEEL_D} strokeWidth="2" />
          <path d="M66 62h24c0 12-5 20-12 20s-12-8-12-20z" fill={WHITE} stroke={STEEL_D} strokeWidth="2" />
          <ellipse cx="78" cy="88" rx="18" ry="4" fill="#eef1f5" stroke={STEEL_D} strokeWidth="2" />
          <path d="M34 54h20" stroke={ORANGE} strokeWidth="3" />
        </g>
      );
    case 'phone':
      return (
        <g>
          <rect x="38" y="14" width="44" height="92" rx="9" fill={NAVY} />
          <rect x="42" y="20" width="36" height="78" rx="5" fill="#2f5fa8" />
          <rect x="42" y="20" width="36" height="78" rx="5" fill="url(#shine)" />
          <rect x="53" y="16" width="14" height="3" rx="1.5" fill="#0a1424" />
          <circle cx="60" cy="58" r="12" fill="none" stroke="#9fc0ee" strokeWidth="2" opacity=".7" />
        </g>
      );
    case 'earbuds':
      return (
        <g>
          <rect x="28" y="56" width="64" height="38" rx="14" fill={WHITE} stroke={STEEL_D} strokeWidth="2" />
          <path d="M28 70h64" stroke={STEEL_D} strokeWidth="2" />
          <circle cx="46" cy="40" r="9" fill={NAVY} />
          <rect x="43" y="40" width="6" height="22" rx="3" fill={NAVY} />
          <circle cx="74" cy="40" r="9" fill={NAVY} />
          <rect x="71" y="40" width="6" height="22" rx="3" fill={NAVY} />
          <circle cx="60" cy="82" r="3" fill={ORANGE} />
        </g>
      );
    case 'charger':
      return (
        <g>
          <rect x="40" y="26" width="40" height="52" rx="8" fill={WHITE} stroke={STEEL_D} strokeWidth="2" />
          <rect x="50" y="12" width="5" height="14" rx="2" fill={STEEL_D} />
          <rect x="65" y="12" width="5" height="14" rx="2" fill={STEEL_D} />
          <rect x="52" y="78" width="16" height="10" rx="3" fill={NAVY} />
          <path d="M64 40l-8 14h8l-6 14" fill="none" stroke={ORANGE} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      );
    case 'powerbank':
      return (
        <g>
          <rect x="34" y="22" width="52" height="76" rx="10" fill={NAVY} />
          <rect x="42" y="34" width="36" height="6" rx="3" fill={ORANGE} />
          <rect x="42" y="46" width="36" height="6" rx="3" fill="#2b3d5a" />
          <rect x="42" y="58" width="36" height="6" rx="3" fill="#2b3d5a" />
          <rect x="48" y="86" width="24" height="5" rx="2" fill="#0a1424" />
        </g>
      );
    case 'watch':
      return (
        <g>
          <rect x="46" y="14" width="28" height="22" rx="5" fill={STEEL_D} />
          <rect x="46" y="84" width="28" height="22" rx="5" fill={STEEL_D} />
          <rect x="36" y="32" width="48" height="56" rx="14" fill={NAVY} />
          <rect x="41" y="37" width="38" height="46" rx="10" fill="#0a1424" />
          <circle cx="60" cy="60" r="12" fill="none" stroke={ORANGE} strokeWidth="3" />
          <path d="M60 52v8l5 3" fill="none" stroke={WHITE} strokeWidth="2.5" strokeLinecap="round" />
        </g>
      );
    case 'speaker':
      return (
        <g>
          <rect x="30" y="34" width="60" height="52" rx="16" fill={NAVY} />
          <circle cx="60" cy="60" r="16" fill="#2b3d5a" />
          <circle cx="60" cy="60" r="6" fill={ORANGE} />
          <path d="M96 48c5 6 5 18 0 24M102 40c9 12 9 28 0 40" fill="none" stroke={STEEL_D} strokeWidth="3" strokeLinecap="round" />
        </g>
      );
    case 'cable':
      return (
        <g>
          <path d="M30 38c30-14 28 26 56 8s8-26-4-20" fill="none" stroke={NAVY} strokeWidth="5" strokeLinecap="round" />
          <rect x="18" y="32" width="18" height="12" rx="3" fill={STEEL_D} />
          <rect x="80" y="14" width="18" height="12" rx="3" fill={STEEL_D} />
          <path d="M30 74c30-14 28 26 56 8" fill="none" stroke={ORANGE} strokeWidth="5" strokeLinecap="round" />
        </g>
      );
    default:
      return (
        <g>
          <rect x="30" y="38" width="60" height="50" rx="6" fill="#e2b98a" stroke="#b98a58" strokeWidth="2" />
          <path d="M30 52h60" stroke="#b98a58" strokeWidth="2" />
          <rect x="52" y="38" width="16" height="14" fill="#f5d9b3" />
        </g>
      );
  }
}

interface Props {
  kind: ArtKind;
  tone?: string;
  size?: number | string;
  rounded?: number;
}

export default function ProductArt({ kind, tone = '#fde7d3', size = '100%', rounded = 14 }: Props) {
  return (
    <svg
      viewBox="0 0 120 120"
      width={size}
      height={size}
      role="img"
      aria-hidden="true"
      style={{ display: 'block', borderRadius: rounded, background: tone }}
    >
      <defs>
        <linearGradient id="shine" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity=".28" />
          <stop offset=".5" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <ellipse cx="60" cy="104" rx="30" ry="4" fill="#000" opacity=".08" />
      <Shapes kind={kind} />
    </svg>
  );
}
