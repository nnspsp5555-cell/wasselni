import { useEffect, useState } from 'react';
import { LogoMark } from './Logo';

// شاشة بداية داخل التطبيق (حوالي ثانية ونصف).
export default function Splash({ onDone }: { onDone: () => void }) {
  const [fade, setFade] = useState(false);
  useEffect(() => {
    const a = window.setTimeout(() => setFade(true), 1200);
    const b = window.setTimeout(onDone, 1600);
    return () => {
      window.clearTimeout(a);
      window.clearTimeout(b);
    };
  }, [onDone]);
  return (
    <div className={`splash ${fade ? 'fade' : ''}`}>
      <LogoMark size={120} />
      <h1>وصّلني</h1>
      <div className="en">Wasselni</div>
      <p>كل احتياجاتك .. من البصرة لبيتك</p>
    </div>
  );
}
