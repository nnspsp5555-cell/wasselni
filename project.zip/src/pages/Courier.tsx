import { useApp } from '../store';
import { couriers } from '../data/demo';
import { mapLink } from '../lib/format';
import OrderCard from './OrderCard';
import Icon from '../components/Icon';

export default function CourierTasks() {
  const { orders, courierId, setOrderStatus, shops } = useApp();
  const me = couriers.find((c) => c.id === courierId);

  // مهام متاحة (جاهزة للتوصيل بلا مندوب) + مهامي
  const available = orders.filter((o) => (o.status === 'accepted' || o.status === 'preparing') && !o.courierId);
  const mine = orders.filter((o) => o.courierId === courierId);

  return (
    <>
      <div className="card row">
        <div className="emoji"><Icon name="truck" size={26} /></div>
        <div>
          <div className="bold">{me?.name}</div>
          <div className="muted small">تتبع الموقع الحي غير مفعّل في هذه النسخة</div>
        </div>
      </div>

      <div className="h2">مهام متاحة</div>
      {available.length === 0 && <div className="muted" style={{ marginBottom: 12 }}>لا توجد مهام متاحة الآن.</div>}
      {available.map((o) => (
        <OrderCard
          key={o.id}
          order={o}
          showCustomer
          actions={
            <>
              <span className="muted small">من: {shops.find((s) => s.id === o.shopId)?.name}</span>
              <button className="btn sm" onClick={() => setOrderStatus(o.id, o.status, courierId)}>قبول المهمة</button>
            </>
          }
        />
      ))}

      <div className="h2">مهامي</div>
      {mine.length === 0 && <div className="muted">لم تقبل مهاماً بعد.</div>}
      {mine.map((o) => (
        <OrderCard
          key={o.id}
          order={o}
          showCustomer
          actions={
            <>
              {(o.status === 'accepted' || o.status === 'preparing') && (
                <button className="btn sm" onClick={() => setOrderStatus(o.id, 'on_the_way')}>استلمت الطلب – بالطريق</button>
              )}
              {o.status === 'on_the_way' && (
                <button className="btn sm" onClick={() => setOrderStatus(o.id, 'delivered')}>تم التسليم</button>
              )}
              <a className="btn ghost sm" href={`tel:${o.customerPhone}`}><Icon name="call" size={15} /> اتصال</a>
              <a className="btn ghost sm" href={mapLink(o.lat, o.lng, o.address)} target="_blank" rel="noreferrer"><Icon name="map" size={15} /> الخريطة</a>
            </>
          }
        />
      ))}
    </>
  );
}
