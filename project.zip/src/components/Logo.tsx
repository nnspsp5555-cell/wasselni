import iconUrl from '../assets/logo-icon.png';
import fullUrl from '../assets/logo-full.png';

interface Props {
  size?: number;
  /** عرض اسم وصّلني بجانب الأيقونة */
  withName?: boolean;
  light?: boolean;
}

/** أيقونة وصّلني (دبوس + سيارة توصيل) */
export function LogoMark({ size = 40 }: { size?: number }) {
  return <img src={iconUrl} width={size} height={size} alt="شعار وصّلني" style={{ display: 'block' }} />;
}

/** الشعار الكامل (الأيقونة + وصّلني + Wasselni + الشعار النصي) على خلفية بيضاء */
export function LogoFull({ width = 240 }: { width?: number }) {
  return <img src={fullUrl} width={width} alt="وصّلني Wasselni" style={{ display: 'block', height: 'auto' }} />;
}

export default function Logo({ size = 40, withName = false, light = false }: Props) {
  if (!withName) return <LogoMark size={size} />;
  return (
    <span className="logo-lockup">
      <LogoMark size={size} />
      <span className="logo-text">
        <b style={{ color: light ? '#fff' : 'var(--navy)' }}>وصّلني</b>
        <i style={{ color: light ? '#ffe3cf' : 'var(--brand)' }}>Wasselni</i>
      </span>
    </span>
  );
}
