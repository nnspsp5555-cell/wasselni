import type { ReactNode } from 'react';
import type { Order } from '../types';
import { STATUS_FLOW, STATUS_LABEL, fmt, mapLink, timeStr } from '../lib/format';
import { useApp } from '../store';
import Icon from '../components/Icon';

export function StatusTag({ status }: { status: Order['status'] }) {
  const cls = status === 'cancelled' ? 'red' : status === 'delivered' ? '' : 'amber';
  return <span className={`tag ${cls}`}>{STATUS_LABEL[status]}</span>;
}

export function Progress({ status }: { status: Order['status'] }) {
  if (status === 'cancelled') return null;
  const idx = STATUS_FLOW.indexOf(status);
  return (
    <div className="steps">
      {STATUS_FLOW.map((s, i) => (
        <div key={s} className={`step ${i <= idx ? 'on' : ''}`} />
      ))}
    </div>
  );
}

interface Props {
  order: Order;
  showCustomer?: boolean;
  actions?: ReactNode;
}

export default function OrderCard({ order, showCustomer, actions }: Props) {
  const { shops } = useApp();
  const shop = shops.find((s) => s.id === order.shopId);
  return (
    <div className="card">
      <div className="row between">
        <div className="bold">
          {order.id} · {shop?.name ?? 'متجر'}
        </div>
        <StatusTag status={order.status} />
      </div>
      <div className="muted small">{timeStr(order.createdAt)}</div>
      <Progress status={order.status} />
      <div style={{ margin: '8px 0' }}>
        {order.lines.map((l) => (
          <div key={l.productId} className="row between small">
            <span>
              {l.qty} × {l.name}
            </span>
            <span>{fmt(l.price * l.qty)}</span>
          </div>
        ))}
      </div>
      <div className="row between bold">
        <span>الإجمالي (نقداً عند الاستلام)</span>
        <span>{fmt(order.total)}</span>
      </div>
      {showCustomer && (
        <div className="muted small" style={{ marginTop: 8 }}>
          <Icon name="user" size={14} /> {order.customerName} · <a href={`tel:${order.customerPhone}`}>{order.customerPhone}</a>
          <br />
          <Icon name="pin" size={14} /> {order.address} ·{' '}
          <a href={mapLink(order.lat, order.lng, order.address)} target="_blank" rel="noreferrer">
            فتح الخريطة
          </a>
        </div>
      )}
      {actions && <div className="row" style={{ marginTop: 10, flexWrap: 'wrap' }}>{actions}</div>}
    </div>
  );
}
