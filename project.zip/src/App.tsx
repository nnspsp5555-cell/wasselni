import { useEffect, useState } from 'react';
import { useApp } from './store';
import { isSupabaseConfigured } from './lib/supabase';
import Login from './pages/Login';
import { CartPage, Home, OrdersPage, ShopPage } from './pages/Customer';
import { MerchantOrders, MerchantProducts } from './pages/Merchant';
import CourierTasks from './pages/Courier';
import { AdminDashboard, AdminOrders, AdminShops } from './pages/Admin';
import type { Role } from './types';

interface TabDef {
  id: string;
  icon: string;
  label: string;
}

const TABS: Record<Role, TabDef[]> = {
  customer: [
    { id: 'home', icon: '🏠', label: 'الرئيسية' },
    { id: 'cart', icon: '🛒', label: 'السلة' },
    { id: 'orders', icon: '📦', label: 'طلباتي' },
    { id: 'account', icon: '👤', label: 'حسابي' },
  ],
  merchant: [
    { id: 'orders', icon: '📥', label: 'الطلبات' },
    { id: 'products', icon: '🏷️', label: 'المنتجات' },
    { id: 'account', icon: '👤', label: 'حسابي' },
  ],
  courier: [
    { id: 'tasks', icon: '🛵', label: 'المهام' },
    { id: 'account', icon: '👤', label: 'حسابي' },
  ],
  admin: [
    { id: 'dash', icon: '📊', label: 'لوحة' },
    { id: 'orders', icon: '📦', label: 'الطلبات' },
    { id: 'shops', icon: '🏪', label: 'المتاجر' },
    { id: 'account', icon: '👤', label: 'حسابي' },
  ],
};

const ROLE_NAME: Record<Role, string> = {
  customer: 'زبون',
  merchant: 'متجر',
  courier: 'مندوب',
  admin: 'مدير',
};

function Account() {
  const { role, logout, resetDemo } = useApp();
  return (
    <>
      <div className="card">
        <div className="bold">نوع الحساب: {role ? ROLE_NAME[role] : ''}</div>
        <div className="muted small" style={{ marginTop: 6 }}>
          وضع تجريبي: البيانات محفوظة على هذا الجهاز فقط.
          <br />
          {isSupabaseConfigured
            ? 'مفاتيح Supabase مضبوطة (الربط الكامل في المرحلة الثانية).'
            : 'Supabase غير مضبوط.'}
        </div>
      </div>
      <button className="btn block ghost" style={{ marginBottom: 10 }} onClick={logout}>
        تبديل نوع الحساب
      </button>
      <button
        className="btn block danger"
        onClick={() => window.confirm('مسح كل البيانات التجريبية؟') && resetDemo()}
      >
        إعادة ضبط البيانات التجريبية
      </button>
    </>
  );
}

export default function App() {
  const { role, cartTotals, toasts, shops, shopId } = useApp();
  const [tab, setTab] = useState('');
  const [openShopId, setOpenShopId] = useState<string | null>(null);

  // عند تغيير الدور نعود إلى أول تبويب
  useEffect(() => {
    setTab(role ? TABS[role][0].id : '');
    setOpenShopId(null);
  }, [role]);

  if (!role) return <Login />;

  const tabs = TABS[role];
  const shopName = shops.find((s) => s.id === shopId)?.name;
  const title =
    role === 'customer' && openShopId
      ? shops.find((s) => s.id === openShopId)?.name ?? 'المتجر'
      : tabs.find((t) => t.id === tab)?.label ?? 'وصّلني';

  let body: JSX.Element | null = null;
  if (role === 'customer') {
    if (tab === 'home') {
      body = openShopId ? <ShopPage shopId={openShopId} /> : <Home openShop={setOpenShopId} />;
    } else if (tab === 'cart') body = <CartPage goOrders={() => setTab('orders')} />;
    else if (tab === 'orders') body = <OrdersPage />;
  } else if (role === 'merchant') {
    if (tab === 'orders') body = <MerchantOrders />;
    else if (tab === 'products') body = <MerchantProducts />;
  } else if (role === 'courier') {
    if (tab === 'tasks') body = <CourierTasks />;
  } else if (role === 'admin') {
    if (tab === 'dash') body = <AdminDashboard />;
    else if (tab === 'orders') body = <AdminOrders />;
    else if (tab === 'shops') body = <AdminShops />;
  }
  if (tab === 'account') body = <Account />;

  return (
    <div className="app">
      <div className="topbar">
        <div>
          <h1>{title}</h1>
          <div className="sub">
            وصّلني · البصرة{role === 'merchant' && shopName ? ` · ${shopName}` : ''} · نسخة تجريبية
          </div>
        </div>
        {role === 'customer' && openShopId && tab === 'home' && (
          <button className="back" onClick={() => setOpenShopId(null)}>
            رجوع ›
          </button>
        )}
      </div>

      <div className="toasts">
        {toasts.map((t) => (
          <div key={t.id} className="toast">
            🔔 {t.text}
          </div>
        ))}
      </div>

      <div className="content">{body}</div>

      <nav className="tabbar">
        {tabs.map((t) => (
          <button
            key={t.id}
            className={`tab ${tab === t.id ? 'active' : ''}`}
            onClick={() => {
              setTab(t.id);
              if (t.id !== 'home') setOpenShopId(null);
            }}
          >
            <span className="ic">{t.icon}</span>
            {t.label}
            {role === 'customer' && t.id === 'cart' && cartTotals.count > 0 && (
              <span className="badge">{cartTotals.count}</span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
}
