interface Props {
  size?: number;
  /** عرض اسم وصّلني بجانب الأيقونة */
  withName?: boolean;
  light?: boolean;
}

export function LogoMark({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 512 512" aria-label="شعار وصّلني" role="img">
      <defs>
        <linearGradient id="wl-bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ff8f2e" />
          <stop offset="1" stopColor="#f05a12" />
        </linearGradient>
      </defs>
      <rect width="512" height="512" rx="112" fill="url(#wl-bg)" />
      <path
        d="M256 70c-72 0-130 56-130 126 0 92 130 244 130 244s130-152 130-244c0-70-58-126-130-126z"
        fill="#fff"
      />
      <g fill="#14233c">
        <rect x="190" y="150" width="70" height="56" rx="8" />
        <circle cx="214" cy="222" r="13" />
        <circle cx="288" cy="222" r="13" />
      </g>
      <path d="M266 168h30c6 0 11 3 14 8l12 20c2 3 3 6 3 10v8h-59z" fill="#f05a12" />
      <path d="M274 178h18l10 16h-28z" fill="#fff" />
      <circle cx="214" cy="222" r="5" fill="#fff" />
      <circle cx="288" cy="222" r="5" fill="#fff" />
      <g stroke="#f05a12" strokeWidth="7" strokeLinecap="round">
        <line x1="150" y1="164" x2="176" y2="164" />
        <line x1="158" y1="182" x2="182" y2="182" />
        <line x1="150" y1="200" x2="172" y2="200" />
      </g>
    </svg>
  );
}

export default function Logo({ size = 40, withName = false, light = false }: Props) {
  if (!withName) return <LogoMark size={size} />;
  return (
    <span className="logo-lockup">
      <LogoMark size={size} />
      <span className="logo-text">
        <b style={{ color: light ? '#fff' : 'var(--navy)' }}>وصّلني</b>
        <i style={{ color: light ? '#ffe3cf' : 'var(--brand)' }}>Wasselni</i>
      </span>
    </span>
  );
}
