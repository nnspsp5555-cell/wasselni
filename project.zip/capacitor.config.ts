import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'iq.wasselni.app',
  appName: 'وصّلني',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
  },
};

export default config;
