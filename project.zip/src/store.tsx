import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type {
  CartLine,
  Offer,
  Order,
  OrderStatus,
  Product,
  Role,
  Settings,
  Shop,
  Toast,
} from './types';
import { offers as demoOffers, products as demoProducts, shops as demoShops } from './data/demo';
import { STATUS_LABEL } from './lib/format';

const KEY = 'wasselni_demo_v1';

interface Persisted {
  role: Role | null;
  shopId: string; // المتجر الذي يديره حساب "المتجر" التجريبي
  courierId: string; // المندوب التجريبي
  cart: CartLine[];
  orders: Order[];
  products: Product[];
  shops: Shop[];
  offers: Offer[];
  settings: Settings;
  profile: { name: string; phone: string; address: string };
}

const initial: Persisted = {
  role: null,
  shopId: 's1',
  courierId: 'c1',
  cart: [],
  orders: [],
  products: demoProducts,
  shops: demoShops,
  offers: demoOffers,
  settings: { commissionPct: 10, city: 'البصرة' },
  profile: { name: '', phone: '', address: '' },
};

function load(): Persisted {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...initial, ...(JSON.parse(raw) as Partial<Persisted>) };
  } catch {
    /* تجاهل */
  }
  return initial;
}

export interface PlaceOrderInput {
  name: string;
  phone: string;
  address: string;
  lat?: number;
  lng?: number;
}

interface Ctx extends Persisted {
  toasts: Toast[];
  login: (role: Role, opts?: { shopId?: string; courierId?: string }) => void;
  logout: () => void;
  addToCart: (productId: string) => void;
  changeQty: (productId: string, delta: number) => void;
  clearCart: () => void;
  cartShop: Shop | undefined;
  cartTotals: { subtotal: number; discount: number; deliveryFee: number; total: number; count: number };
  placeOrder: (i: PlaceOrderInput) => Order | null;
  setOrderStatus: (id: string, status: OrderStatus, courierId?: string) => void;
  rateOrder: (id: string, rating: number) => void;
  updateProduct: (id: string, patch: Partial<Product>) => void;
  addProduct: (p: Omit<Product, 'id'>) => void;
  deleteProduct: (id: string) => void;
  updateShop: (id: string, patch: Partial<Shop>) => void;
  toggleOffer: (id: string) => void;
  setCommission: (n: number) => void;
  setProfile: (p: Partial<Persisted['profile']>) => void;
  resetDemo: () => void;
  notify: (text: string) => void;
}

const AppCtx = createContext<Ctx | null>(null);

export function useApp(): Ctx {
  const c = useContext(AppCtx);
  if (!c) throw new Error('useApp خارج AppProvider');
  return c;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<Persisted>(load);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const toastId = useRef(1);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(s));
    } catch {
      /* التخزين غير متاح */
    }
  }, [s]);

  const notify = useCallback((text: string) => {
    const id = toastId.current++;
    setToasts((t) => [...t, { id, text }]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500);
  }, []);

  const login: Ctx['login'] = (role, opts) =>
    setS((p) => ({
      ...p,
      role,
      shopId: opts?.shopId ?? p.shopId,
      courierId: opts?.courierId ?? p.courierId,
    }));

  const logout = () => setS((p) => ({ ...p, role: null }));

  const addToCart: Ctx['addToCart'] = (productId) => {
    const prod = s.products.find((x) => x.id === productId);
    if (!prod) return;
    const shop = s.shops.find((x) => x.id === prod.shopId);
    if (!shop || !shop.open) {
      notify('المتجر مغلق حالياً');
      return;
    }
    const current = s.cart[0] ? s.products.find((x) => x.id === s.cart[0].productId) : undefined;
    if (current && current.shopId !== prod.shopId) {
      if (!window.confirm('السلة تحتوي منتجات من متجر آخر. هل تريد تفريغها والبدء من هذا المتجر؟')) return;
      setS((p) => ({ ...p, cart: [{ productId, qty: 1 }] }));
      return;
    }
    setS((p) => {
      const line = p.cart.find((l) => l.productId === productId);
      if (line) {
        if (line.qty >= prod.stock) {
          return p;
        }
        return { ...p, cart: p.cart.map((l) => (l.productId === productId ? { ...l, qty: l.qty + 1 } : l)) };
      }
      if (prod.stock < 1) return p;
      return { ...p, cart: [...p.cart, { productId, qty: 1 }] };
    });
  };

  const changeQty: Ctx['changeQty'] = (productId, delta) =>
    setS((p) => {
      const prod = p.products.find((x) => x.id === productId);
      const cart = p.cart
        .map((l) =>
          l.productId === productId
            ? { ...l, qty: Math.min(l.qty + delta, prod ? prod.stock : l.qty + delta) }
            : l,
        )
        .filter((l) => l.qty > 0);
      return { ...p, cart };
    });

  const clearCart = () => setS((p) => ({ ...p, cart: [] }));

  const cartShop = useMemo(() => {
    const first = s.cart[0];
    if (!first) return undefined;
    const prod = s.products.find((x) => x.id === first.productId);
    return prod ? s.shops.find((x) => x.id === prod.shopId) : undefined;
  }, [s.cart, s.products, s.shops]);

  const cartTotals = useMemo(() => {
    const subtotal = s.cart.reduce((sum, l) => {
      const prod = s.products.find((x) => x.id === l.productId);
      return sum + (prod ? prod.price * l.qty : 0);
    }, 0);
    const offer = cartShop ? s.offers.find((o) => o.shopId === cartShop.id && o.active) : undefined;
    const discount = offer ? Math.round((subtotal * offer.discountPct) / 100) : 0;
    const deliveryFee = cartShop && s.cart.length ? cartShop.deliveryFee : 0;
    return {
      subtotal,
      discount,
      deliveryFee,
      total: subtotal - discount + deliveryFee,
      count: s.cart.reduce((n, l) => n + l.qty, 0),
    };
  }, [s.cart, s.products, s.offers, cartShop]);

  const placeOrder: Ctx['placeOrder'] = (info) => {
    if (!cartShop || s.cart.length === 0) return null;
    const lines = s.cart.flatMap((l) => {
      const prod = s.products.find((x) => x.id === l.productId);
      return prod ? [{ productId: prod.id, name: prod.name, price: prod.price, qty: l.qty }] : [];
    });
    const order: Order = {
      id: `W${1001 + s.orders.length}`,
      shopId: cartShop.id,
      lines,
      subtotal: cartTotals.subtotal,
      discount: cartTotals.discount,
      deliveryFee: cartTotals.deliveryFee,
      total: cartTotals.total,
      status: 'new',
      address: info.address,
      lat: info.lat,
      lng: info.lng,
      customerName: info.name,
      customerPhone: info.phone,
      createdAt: Date.now(),
      payment: 'cash',
    };
    setS((p) => ({
      ...p,
      orders: [order, ...p.orders],
      cart: [],
      // خصم المخزون
      products: p.products.map((pr) => {
        const l = lines.find((x) => x.productId === pr.id);
        return l ? { ...pr, stock: Math.max(0, pr.stock - l.qty) } : pr;
      }),
      profile: { name: info.name, phone: info.phone, address: info.address },
    }));
    notify(`تم إنشاء الطلب ${order.id} (تجريبي)`);
    return order;
  };

  const setOrderStatus: Ctx['setOrderStatus'] = (id, status, courierId) => {
    setS((p) => ({
      ...p,
      orders: p.orders.map((o) =>
        o.id === id ? { ...o, status, courierId: courierId ?? o.courierId } : o,
      ),
    }));
    notify(`الطلب ${id}: ${STATUS_LABEL[status]}`);
  };

  const rateOrder: Ctx['rateOrder'] = (id, rating) =>
    setS((p) => ({ ...p, orders: p.orders.map((o) => (o.id === id ? { ...o, rating } : o)) }));

  const updateProduct: Ctx['updateProduct'] = (id, patch) =>
    setS((p) => ({ ...p, products: p.products.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));

  const addProduct: Ctx['addProduct'] = (pr) =>
    setS((p) => ({ ...p, products: [...p.products, { ...pr, id: `p${Date.now()}` }] }));

  const deleteProduct: Ctx['deleteProduct'] = (id) =>
    setS((p) => ({
      ...p,
      products: p.products.filter((x) => x.id !== id),
      cart: p.cart.filter((l) => l.productId !== id),
    }));

  const updateShop: Ctx['updateShop'] = (id, patch) =>
    setS((p) => ({ ...p, shops: p.shops.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));

  const toggleOffer: Ctx['toggleOffer'] = (id) =>
    setS((p) => ({ ...p, offers: p.offers.map((o) => (o.id === id ? { ...o, active: !o.active } : o)) }));

  const setCommission = (n: number) =>
    setS((p) => ({ ...p, settings: { ...p.settings, commissionPct: Math.max(0, Math.min(50, n)) } }));

  const setProfile: Ctx['setProfile'] = (pr) => setS((p) => ({ ...p, profile: { ...p.profile, ...pr } }));

  const resetDemo = () => {
    try {
      localStorage.removeItem(KEY);
    } catch {
      /* تجاهل */
    }
    setS({ ...initial });
  };

  const value: Ctx = {
    ...s,
    toasts,
    login,
    logout,
    addToCart,
    changeQty,
    clearCart,
    cartShop,
    cartTotals,
    placeOrder,
    setOrderStatus,
    rateOrder,
    updateProduct,
    addProduct,
    deleteProduct,
    updateShop,
    toggleOffer,
    setCommission,
    setProfile,
    resetDemo,
    notify,
  };

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}
