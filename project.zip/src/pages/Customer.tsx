import { useMemo, useState } from 'react';
import { useApp } from '../store';
import { categories } from '../data/demo';
import ProductArt from '../components/ProductArt';
import type { Category, Product, Shop } from '../types';
import { fmt } from '../lib/format';
import { getMyLocation } from '../lib/location';
import OrderCard from './OrderCard';

export type Route =
  | { name: 'home' }
  | { name: 'category'; id: string }
  | { name: 'shop'; id: string }
  | { name: 'product'; id: string };

interface Nav {
  go: (r: Route) => void;
}

function ComingSoonTile({ c }: { c: Category }) {
  return (
    <div className="soon" role="button" aria-disabled="true" title="جاري العمل">
      <span className="lock">🔒</span>
      <div className="soon-ic">{c.icon}</div>
      <div className="soon-name">{c.short}</div>
      <span className="tag amber">جاري العمل</span>
    </div>
  );
}

export function ProductCard({ p, go }: { p: Product } & Nav) {
  const { addToCart, shops } = useApp();
  const shop = shops.find((s) => s.id === p.shopId);
  return (
    <div className="pcard">
      <button className="pcard-main" onClick={() => go({ name: 'product', id: p.id })}>
        <div className="pcard-art">
          <ProductArt kind={p.art} tone={p.tone} rounded={14} />
          {p.badge && <span className="pbadge">{p.badge}</span>}
        </div>
        <div className="pname">{p.name}</div>
        <div className="muted small">{shop?.name}</div>
        <div className="price">{fmt(p.price)}</div>
      </button>
      <button className="btn sm block-btn" disabled={p.stock < 1 || !shop?.open} onClick={() => addToCart(p.id)}>
        {p.stock < 1 ? 'نفد' : '+ أضف إلى السلة'}
      </button>
    </div>
  );
}

export function Home({ go }: Nav) {
  const { shops, products, offers } = useApp();
  const [q, setQ] = useState('');
  const query = q.trim();

  const active = categories.filter((c) => c.enabled);
  const soon = categories.filter((c) => !c.enabled);
  const activeOffers = offers.filter((o) => o.active);

  const productHits = useMemo(
    () =>
      query
        ? products.filter(
            (p) =>
              categories.find((c) => c.id === p.categoryId)?.enabled &&
              (p.name.includes(query) || p.desc.includes(query)),
          )
        : [],
    [products, query],
  );
  const shopHits = useMemo(
    () => (query ? shops.filter((s) => s.name.includes(query)) : []),
    [shops, query],
  );
  const soonHit = query ? soon.find((c) => c.name.includes(query) || c.short.includes(query)) : undefined;

  return (
    <>
      <div className="searchbox">
        <span>🔍</span>
        <input
          placeholder="ابحث عن منتج أو متجر…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        {q && (
          <button className="clear" onClick={() => setQ('')} aria-label="مسح">
            ✕
          </button>
        )}
      </div>

      {query ? (
        <>
          {soonHit && (
            <div className="card tag amber" style={{ display: 'block' }}>
              🔒 قسم «{soonHit.name}» — جاري العمل وسيتوفر لاحقاً
            </div>
          )}
          <div className="h2">المنتجات ({productHits.length})</div>
          {productHits.length === 0 && (
            <div className="empty">
              <div className="big">🔎</div>لا توجد منتجات مطابقة
            </div>
          )}
          <div className="pgrid">
            {productHits.map((p) => (
              <ProductCard key={p.id} p={p} go={go} />
            ))}
          </div>
          {shopHits.length > 0 && (
            <>
              <div className="h2">المتاجر</div>
              {shopHits.map((s) => (
                <ShopRow key={s.id} shop={s} go={go} />
              ))}
            </>
          )}
        </>
      ) : (
        <>
          {activeOffers.length > 0 && (
            <div className="hero">
              <div className="hero-text">
                <b>عروض خاصة</b>
                <span>{activeOffers[0].title}</span>
                <button className="btn sm white" onClick={() => go({ name: 'shop', id: activeOffers[0].shopId })}>
                  تسوّق الآن
                </button>
                <div className="small" style={{ opacity: 0.85 }}>عرض توضيحي</div>
              </div>
              <div className="hero-art">🛍️</div>
            </div>
          )}

          <div className="h2">الأقسام المتاحة</div>
          <div className="catgrid">
            {active.map((c) => (
              <button key={c.id} className="catcard" onClick={() => go({ name: 'category', id: c.id })}>
                <span className="cat-ic">{c.icon}</span>
                <b>{c.name}</b>
                <span className="muted small">
                  {products.filter((p) => p.categoryId === c.id).length} منتج
                </span>
              </button>
            ))}
          </div>

          <div className="h2">منتجات مختارة</div>
          <div className="pgrid">
            {products
              .filter((p) => categories.find((c) => c.id === p.categoryId)?.enabled)
              .filter((_, i) => i % 2 === 0)
              .slice(0, 6)
              .map((p) => (
                <ProductCard key={p.id} p={p} go={go} />
              ))}
          </div>
          <div className="muted small" style={{ margin: '4px 2px 12px' }}>
            المنتجات والأسعار توضيحية للتجربة فقط وليست أسعاراً حقيقية من متاجر البصرة.
          </div>

          <div className="h2">أقسام قادمة</div>
          <div className="soongrid">
            {soon.map((c) => (
              <ComingSoonTile key={c.id} c={c} />
            ))}
          </div>

          <div className="h2">المتاجر التجريبية</div>
          {shops.map((s) => (
            <ShopRow key={s.id} shop={s} go={go} />
          ))}
        </>
      )}
    </>
  );
}

function ShopRow({ shop, go }: { shop: Shop } & Nav) {
  return (
    <button className={`shop ${shop.open ? '' : 'closed'}`} onClick={() => go({ name: 'shop', id: shop.id })}>
      <div className="emoji">{shop.emoji}</div>
      <div className="grow">
        <div className="bold">{shop.name}</div>
        <div className="muted small">
          {shop.area} · ⭐ {shop.rating} · {shop.etaMin} دقيقة · توصيل {fmt(shop.deliveryFee)}
        </div>
      </div>
      <span className={`tag ${shop.open ? '' : 'red'}`}>{shop.open ? 'مفتوح' : 'مغلق'}</span>
    </button>
  );
}

export function CategoryPage({ id, go }: { id: string } & Nav) {
  const { products } = useApp();
  const cat = categories.find((c) => c.id === id);
  const [q, setQ] = useState('');
  if (!cat || !cat.enabled)
    return (
      <div className="empty">
        <div className="big">🔒</div>هذا القسم «جاري العمل»
      </div>
    );
  const query = q.trim();
  const list = products.filter(
    (p) => p.categoryId === id && (!query || p.name.includes(query) || p.desc.includes(query)),
  );
  return (
    <>
      <div className="searchbox">
        <span>🔍</span>
        <input placeholder={`ابحث في ${cat.short}…`} value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="h2">
        {cat.icon} {cat.name}
      </div>
      {list.length === 0 && (
        <div className="empty">
          <div className="big">🔎</div>لا توجد منتجات مطابقة
        </div>
      )}
      <div className="pgrid">
        {list.map((p) => (
          <ProductCard key={p.id} p={p} go={go} />
        ))}
      </div>
    </>
  );
}

export function ProductPage({ id, go }: { id: string } & Nav) {
  const { products, shops, cart, addToCart, changeQty } = useApp();
  const p = products.find((x) => x.id === id);
  if (!p) return <div className="empty">المنتج غير موجود</div>;
  const shop = shops.find((s) => s.id === p.shopId);
  const line = cart.find((l) => l.productId === p.id);
  return (
    <>
      <div className="pdetail-art">
        <ProductArt kind={p.art} tone={p.tone} rounded={20} />
      </div>
      <div className="card">
        <div className="row between">
          <div className="bold" style={{ fontSize: 18 }}>{p.name}</div>
          {p.badge && <span className="tag amber">{p.badge}</span>}
        </div>
        <div className="price big-price">{fmt(p.price)}</div>
        <div className="muted small">سعر توضيحي للتجربة</div>
        <p style={{ margin: '10px 0' }}>{p.desc}</p>
        {p.specs && (
          <ul className="specs">
            {p.specs.map((x) => (
              <li key={x}>{x}</li>
            ))}
          </ul>
        )}
        <div className="muted small">
          {p.stock > 0 ? `المتوفر: ${p.stock}` : 'غير متوفر حالياً'}
        </div>
      </div>
      {shop && (
        <button className="shop" onClick={() => go({ name: 'shop', id: shop.id })}>
          <div className="emoji">{shop.emoji}</div>
          <div className="grow">
            <div className="bold">{shop.name}</div>
            <div className="muted small">
              {shop.area} · ⭐ {shop.rating} · توصيل {fmt(shop.deliveryFee)}
            </div>
          </div>
          <span className="muted">‹</span>
        </button>
      )}
      <div className="stickybar">
        {line ? (
          <div className="qty">
            <button onClick={() => changeQty(p.id, -1)}>−</button>
            <b>{line.qty}</b>
            <button onClick={() => addToCart(p.id)}>+</button>
          </div>
        ) : null}
        <button className="btn grow" disabled={p.stock < 1 || !shop?.open} onClick={() => addToCart(p.id)}>
          {p.stock < 1 ? 'نفد' : !shop?.open ? 'المتجر مغلق' : line ? 'إضافة المزيد' : 'أضف إلى السلة'}
        </button>
      </div>
    </>
  );
}

export function ShopPage({ shopId, go }: { shopId: string } & Nav) {
  const { shops, products, offers } = useApp();
  const shop = shops.find((s) => s.id === shopId);
  if (!shop) return <div className="empty">المتجر غير موجود</div>;
  const offer = offers.find((o) => o.shopId === shopId && o.active);
  const list = products.filter((p) => p.shopId === shopId);
  return (
    <>
      <div className="card row">
        <div className="emoji">{shop.emoji}</div>
        <div className="grow">
          <div className="bold">{shop.name}</div>
          <div className="muted small">
            {shop.area} · ⭐ {shop.rating} · {shop.etaMin} دقيقة
          </div>
          <div className="muted small">رسوم التوصيل {fmt(shop.deliveryFee)}</div>
        </div>
        <a className="btn ghost sm" href={`tel:${shop.phone}`}>
          📞
        </a>
      </div>
      {offer && <div className="card tag amber" style={{ display: 'block' }}>🔥 {offer.title} — يُطبّق تلقائياً في السلة</div>}
      {!shop.open && <div className="card tag red" style={{ display: 'block' }}>المتجر مغلق حالياً</div>}
      <div className="pgrid">
        {list.map((p) => (
          <ProductCard key={p.id} p={p} go={go} />
        ))}
      </div>
    </>
  );
}

export function CartPage({ goOrders }: { goOrders: () => void }) {
  const { cart, products, cartShop, cartTotals, changeQty, clearCart, placeOrder, profile } = useApp();
  const [name, setName] = useState(profile.name);
  const [phone, setPhone] = useState(profile.phone);
  const [address, setAddress] = useState(profile.address);
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [locMsg, setLocMsg] = useState('');
  const [busy, setBusy] = useState(false);

  if (cart.length === 0)
    return (
      <div className="empty">
        <div className="big">🛒</div>السلة فارغة
      </div>
    );

  const locate = async () => {
    setBusy(true);
    setLocMsg('');
    try {
      setPos(await getMyLocation());
    } catch {
      setLocMsg('تعذّر تحديد الموقع. تأكد من تفعيل GPS وإعطاء الإذن، أو اكتب العنوان يدوياً.');
    } finally {
      setBusy(false);
    }
  };

  const phoneOk = /^07\d{9}$/.test(phone.trim());
  const valid = name.trim().length > 1 && phoneOk && address.trim().length > 3;

  const submit = () => {
    if (!valid) return;
    const o = placeOrder({ name: name.trim(), phone: phone.trim(), address: address.trim(), lat: pos?.lat, lng: pos?.lng });
    if (o) goOrders();
  };

  return (
    <>
      <div className="row between">
        <div className="h2">سلة {cartShop?.name}</div>
        <button className="btn danger sm" onClick={clearCart}>
          تفريغ
        </button>
      </div>
      {cart.map((l) => {
        const p = products.find((x) => x.id === l.productId);
        if (!p) return null;
        return (
          <div key={l.productId} className="card row">
            <div style={{ width: 52 }}><ProductArt kind={p.art} tone={p.tone} rounded={12} /></div>
            <div className="grow">
              <div className="bold">{p.name}</div>
              <div className="muted small">{fmt(p.price)}</div>
            </div>
            <div className="qty">
              <button onClick={() => changeQty(l.productId, -1)}>−</button>
              <b>{l.qty}</b>
              <button onClick={() => changeQty(l.productId, 1)}>+</button>
            </div>
          </div>
        );
      })}

      <div className="card">
        <div className="bold" style={{ marginBottom: 8 }}>بيانات التوصيل</div>
        <label className="field">
          <span>الاسم</span>
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <label className="field">
          <span>رقم الهاتف (07XXXXXXXXX)</span>
          <input inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </label>
        {phone && !phoneOk && <div className="muted small" style={{ color: 'var(--danger)' }}>أدخل رقماً عراقياً صحيحاً من 11 رقم</div>}
        <label className="field">
          <span>العنوان (المنطقة، الشارع، أقرب نقطة دالة)</span>
          <textarea rows={2} value={address} onChange={(e) => setAddress(e.target.value)} />
        </label>
        <button className="btn ghost" onClick={locate} disabled={busy}>
          📍 {busy ? 'جارٍ التحديد…' : pos ? 'تحديث موقعي' : 'تحديد موقعي على الخريطة'}
        </button>
        {locMsg && <div className="muted small" style={{ marginTop: 6 }}>{locMsg}</div>}
        {pos && (
          <iframe
            className="map"
            title="موقعك"
            src={`https://www.openstreetmap.org/export/embed.html?bbox=${pos.lng - 0.004}%2C${pos.lat - 0.003}%2C${pos.lng + 0.004}%2C${pos.lat + 0.003}&layer=mapnik&marker=${pos.lat}%2C${pos.lng}`}
          />
        )}
      </div>

      <div className="card sum">
        <div><span>المنتجات</span><span>{fmt(cartTotals.subtotal)}</span></div>
        {cartTotals.discount > 0 && (
          <div><span>الخصم</span><span>− {fmt(cartTotals.discount)}</span></div>
        )}
        <div><span>رسوم التوصيل</span><span>{fmt(cartTotals.deliveryFee)}</span></div>
        <div className="total"><span>الإجمالي</span><span>{fmt(cartTotals.total)}</span></div>
        <div className="muted small" style={{ marginTop: 6 }}>💵 الدفع نقداً عند الاستلام (الدفع الإلكتروني لاحقاً)</div>
      </div>

      <button className="btn block" disabled={!valid} onClick={submit}>
        تأكيد الطلب (تجريبي)
      </button>
    </>
  );
}

export function OrdersPage() {
  const { orders, setOrderStatus, rateOrder } = useApp();
  if (orders.length === 0)
    return (
      <div className="empty">
        <div className="big">📦</div>لا توجد طلبات بعد
      </div>
    );
  return (
    <>
      {orders.map((o) => (
        <OrderCard
          key={o.id}
          order={o}
          showCustomer={false}
          actions={
            <>
              {o.status === 'new' && (
                <button className="btn danger sm" onClick={() => setOrderStatus(o.id, 'cancelled')}>
                  إلغاء الطلب
                </button>
              )}
              {o.status === 'delivered' && (
                <div className="stars row">
                  <span className="muted small">تقييمك:</span>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button key={n} className={(o.rating ?? 0) >= n ? 'on' : ''} onClick={() => rateOrder(o.id, n)}>
                      ★
                    </button>
                  ))}
                </div>
              )}
            </>
          }
        />
      ))}
    </>
  );
}
