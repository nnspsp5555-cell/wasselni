import { useApp } from '../store';
import { isSupabaseConfigured } from '../lib/supabase';
import { shops, couriers } from '../data/demo';
import type { Role } from '../types';

const ROLES: { role: Role; icon: string; title: string; desc: string }[] = [
  { role: 'customer', icon: '🛍️', title: 'زبون', desc: 'تصفح المتاجر واطلب' },
  { role: 'merchant', icon: '🏪', title: 'متجر', desc: 'إدارة المنتجات والطلبات' },
  { role: 'courier', icon: '🛵', title: 'مندوب', desc: 'مهام التوصيل' },
  { role: 'admin', icon: '🛠️', title: 'مدير', desc: 'لوحة الإدارة' },
];

export default function Login() {
  const { login } = useApp();
  return (
    <div className="login">
      <h1>وصّلني</h1>
      <div style={{ opacity: 0.9, marginBottom: 16 }}>توصيل من متاجر البصرة إلى باب بيتك</div>

      <div className="demo-note">
        ⚠️ <b>نسخة تجريبية:</b> الدخول هنا لاختيار نوع الحساب فقط، والبيانات تُحفظ على هذا الجهاز فقط ولا تُرسل إلى
        الإنترنت.
        {isSupabaseConfigured
          ? ' (تم ضبط مفاتيح Supabase، لكن ربط الحسابات الحقيقية يأتي في المرحلة الثانية.)'
          : ' (مفاتيح Supabase غير مضبوطة.)'}
      </div>

      {ROLES.map((r) => (
        <button
          key={r.role}
          className="role-btn"
          onClick={() =>
            login(r.role, {
              shopId: r.role === 'merchant' ? shops[0].id : undefined,
              courierId: r.role === 'courier' ? couriers[0].id : undefined,
            })
          }
        >
          <span style={{ fontSize: 30 }}>{r.icon}</span>
          <span>
            <b>{r.title}</b>
            <div className="muted">{r.desc}</div>
          </span>
        </button>
      ))}
    </div>
  );
}
