import type { Category, Courier, Offer, Product, Shop } from '../types';

export const CITIES = ['البصرة'];

export const categories: Category[] = [
  { id: 'food', name: 'مطاعم', icon: '🍔' },
  { id: 'grocery', name: 'بقالة', icon: '🛒' },
  { id: 'sweets', name: 'حلويات', icon: '🍰' },
  { id: 'pharmacy', name: 'صيدلية', icon: '💊' },
  { id: 'cafe', name: 'مقاهي', icon: '☕' },
  { id: 'veg', name: 'خضار وفواكه', icon: '🥬' },
];

export const shops: Shop[] = [
  { id: 's1', name: 'مطعم شط العرب', categoryId: 'food', rating: 4.7, etaMin: 35, deliveryFee: 2000, emoji: '🍗', area: 'العشار', open: true, phone: '07700000001' },
  { id: 's2', name: 'سوبرماركت الفيحاء', categoryId: 'grocery', rating: 4.5, etaMin: 40, deliveryFee: 2500, emoji: '🛍️', area: 'الجزائر', open: true, phone: '07700000002' },
  { id: 's3', name: 'حلويات السندباد', categoryId: 'sweets', rating: 4.8, etaMin: 30, deliveryFee: 2000, emoji: '🧁', area: 'البراضعية', open: true, phone: '07700000003' },
  { id: 's4', name: 'صيدلية الرافدين', categoryId: 'pharmacy', rating: 4.6, etaMin: 25, deliveryFee: 1500, emoji: '💊', area: 'التنومة', open: true, phone: '07700000004' },
  { id: 's5', name: 'قهوة النخيل', categoryId: 'cafe', rating: 4.4, etaMin: 20, deliveryFee: 1500, emoji: '☕', area: 'العشار', open: false, phone: '07700000005' },
  { id: 's6', name: 'خضار أبو فلاح', categoryId: 'veg', rating: 4.3, etaMin: 45, deliveryFee: 2000, emoji: '🍅', area: 'الجزائر', open: true, phone: '07700000006' },
];

export const products: Product[] = [
  { id: 'p1', shopId: 's1', name: 'وجبة دجاج مشوي', price: 9000, stock: 30, emoji: '🍗', desc: 'نصف دجاجة مع رز وسلطة' },
  { id: 'p2', shopId: 's1', name: 'برغر لحم', price: 6500, stock: 40, emoji: '🍔', desc: 'برغر مع بطاطا مقلية' },
  { id: 'p3', shopId: 's1', name: 'شاورما عربي', price: 3500, stock: 50, emoji: '🌯', desc: 'شاورما دجاج بالثوم' },
  { id: 'p4', shopId: 's1', name: 'سمك مسكوف', price: 15000, stock: 10, emoji: '🐟', desc: 'مسكوف بصري مع خبز' },
  { id: 'p5', shopId: 's2', name: 'رز بسمتي 5 كغم', price: 12500, stock: 25, emoji: '🍚', desc: 'رز هندي فاخر' },
  { id: 'p6', shopId: 's2', name: 'زيت طبخ 1.5 لتر', price: 4500, stock: 60, emoji: '🫒', desc: 'زيت نباتي' },
  { id: 'p7', shopId: 's2', name: 'حليب 1 لتر', price: 1500, stock: 80, emoji: '🥛', desc: 'حليب طازج' },
  { id: 'p8', shopId: 's2', name: 'بيض (30 حبة)', price: 6000, stock: 35, emoji: '🥚', desc: 'بيض طازج' },
  { id: 'p9', shopId: 's3', name: 'كيكة شوكولاتة', price: 18000, stock: 8, emoji: '🍰', desc: 'كيكة كاملة' },
  { id: 'p10', shopId: 's3', name: 'بقلاوة (علبة)', price: 10000, stock: 20, emoji: '🥮', desc: 'علبة 12 قطعة' },
  { id: 'p11', shopId: 's3', name: 'كليجة بالتمر', price: 5000, stock: 40, emoji: '🍪', desc: 'كليجة عراقية' },
  { id: 'p12', shopId: 's4', name: 'مسكن صداع', price: 1500, stock: 100, emoji: '💊', desc: 'علبة 10 أقراص' },
  { id: 'p13', shopId: 's4', name: 'فيتامين سي', price: 4000, stock: 50, emoji: '🍊', desc: 'أقراص فوارة' },
  { id: 'p14', shopId: 's5', name: 'شاي استكان', price: 1000, stock: 100, emoji: '🍵', desc: 'شاي عراقي' },
  { id: 'p15', shopId: 's5', name: 'قهوة عربية', price: 2000, stock: 100, emoji: '☕', desc: 'دلة صغيرة' },
  { id: 'p16', shopId: 's6', name: 'طماطم 1 كغم', price: 1250, stock: 90, emoji: '🍅', desc: 'طماطم بصرية' },
  { id: 'p17', shopId: 's6', name: 'خيار 1 كغم', price: 1000, stock: 90, emoji: '🥒', desc: 'خيار طازج' },
  { id: 'p18', shopId: 's6', name: 'تمر زهدي 1 كغم', price: 3500, stock: 40, emoji: '🌴', desc: 'تمر البصرة' },
];

export const offers: Offer[] = [
  { id: 'o1', title: 'خصم 15% من شط العرب', desc: 'على جميع الوجبات', shopId: 's1', discountPct: 15, active: true },
  { id: 'o2', title: 'خصم 10% حلويات السندباد', desc: 'عرض نهاية الأسبوع', shopId: 's3', discountPct: 10, active: true },
  { id: 'o3', title: 'خصم 5% الفيحاء', desc: 'على المشتريات', shopId: 's2', discountPct: 5, active: false },
];

export const couriers: Courier[] = [
  { id: 'c1', name: 'علي الموسوي', phone: '07800000001' },
  { id: 'c2', name: 'حيدر الساعدي', phone: '07800000002' },
];

export const demoCustomers = [
  { id: 'u1', name: 'زبون تجريبي', phone: '07900000001' },
];
