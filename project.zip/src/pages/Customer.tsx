import { useMemo, useState } from 'react';
import { useApp } from '../store';
import { categories } from '../data/demo';
import { fmt } from '../lib/format';
import { getMyLocation } from '../lib/location';
import OrderCard from './OrderCard';

export type CustomerView = 'home' | 'cart' | 'orders' | 'account';

export function Home({ openShop }: { openShop: (id: string) => void }) {
  const { shops, products, offers } = useApp();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState<string>('all');

  const query = q.trim();
  const shopsFiltered = useMemo(
    () =>
      shops.filter(
        (s) => (cat === 'all' || s.categoryId === cat) && (!query || s.name.includes(query)),
      ),
    [shops, cat, query],
  );
  const productHits = useMemo(
    () => (query ? products.filter((p) => p.name.includes(query)) : []),
    [products, query],
  );
  const activeOffers = offers.filter((o) => o.active);

  return (
    <>
      <input
        className="search"
        placeholder="🔍 ابحث عن متجر أو منتج…"
        value={q}
        onChange={(e) => setQ(e.target.value)}
      />

      {!query && activeOffers.length > 0 && (
        <>
          <div className="h2">🔥 العروض</div>
          <div className="offers">
            {activeOffers.map((o) => (
              <button key={o.id} className="offer" onClick={() => openShop(o.shopId)}>
                <b>{o.title}</b>
                <span className="small">{o.desc}</span>
              </button>
            ))}
          </div>
        </>
      )}

      <div className="chips">
        <button className={`chip ${cat === 'all' ? 'active' : ''}`} onClick={() => setCat('all')}>
          الكل
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            className={`chip ${cat === c.id ? 'active' : ''}`}
            onClick={() => setCat(c.id)}
          >
            {c.icon} {c.name}
          </button>
        ))}
      </div>

      {productHits.length > 0 && (
        <>
          <div className="h2">منتجات مطابقة</div>
          {productHits.map((p) => {
            const shop = shops.find((s) => s.id === p.shopId);
            return (
              <button key={p.id} className="shop" onClick={() => openShop(p.shopId)}>
                <div className="emoji">{p.emoji}</div>
                <div className="grow">
                  <div className="bold">{p.name}</div>
                  <div className="muted small">{shop?.name}</div>
                </div>
                <div className="bold">{fmt(p.price)}</div>
              </button>
            );
          })}
        </>
      )}

      <div className="h2">المتاجر في البصرة</div>
      {shopsFiltered.length === 0 && (
        <div className="empty">
          <div className="big">🔎</div>لا توجد نتائج
        </div>
      )}
      {shopsFiltered.map((s) => (
        <button key={s.id} className={`shop ${s.open ? '' : 'closed'}`} onClick={() => openShop(s.id)}>
          <div className="emoji">{s.emoji}</div>
          <div className="grow">
            <div className="bold">{s.name}</div>
            <div className="muted small">
              {s.area} · ⭐ {s.rating} · {s.etaMin} دقيقة · توصيل {fmt(s.deliveryFee)}
            </div>
          </div>
          <span className={`tag ${s.open ? '' : 'red'}`}>{s.open ? 'مفتوح' : 'مغلق'}</span>
        </button>
      ))}
    </>
  );
}

export function ShopPage({ shopId }: { shopId: string }) {
  const { shops, products, offers, addToCart, cart, changeQty } = useApp();
  const shop = shops.find((s) => s.id === shopId);
  if (!shop) return <div className="empty">المتجر غير موجود</div>;
  const offer = offers.find((o) => o.shopId === shopId && o.active);
  const list = products.filter((p) => p.shopId === shopId);
  return (
    <>
      <div className="card row">
        <div className="emoji">{shop.emoji}</div>
        <div className="grow">
          <div className="bold">{shop.name}</div>
          <div className="muted small">
            {shop.area} · ⭐ {shop.rating} · {shop.etaMin} دقيقة
          </div>
          <div className="muted small">رسوم التوصيل {fmt(shop.deliveryFee)}</div>
        </div>
        <a className="btn ghost sm" href={`tel:${shop.phone}`}>
          📞
        </a>
      </div>
      {offer && <div className="card tag amber" style={{ display: 'block' }}>🔥 {offer.title} — يُطبّق تلقائياً في السلة</div>}
      {!shop.open && <div className="card tag red" style={{ display: 'block' }}>المتجر مغلق حالياً</div>}
      {list.map((p) => {
        const line = cart.find((l) => l.productId === p.id);
        return (
          <div key={p.id} className="card row">
            <div className="emoji">{p.emoji}</div>
            <div className="grow">
              <div className="bold">{p.name}</div>
              <div className="muted small">{p.desc}</div>
              <div className="bold">{fmt(p.price)}</div>
            </div>
            {p.stock < 1 ? (
              <span className="tag red">نفد</span>
            ) : line ? (
              <div className="qty">
                <button onClick={() => changeQty(p.id, -1)}>−</button>
                <b>{line.qty}</b>
                <button onClick={() => addToCart(p.id)}>+</button>
              </div>
            ) : (
              <button className="btn sm" disabled={!shop.open} onClick={() => addToCart(p.id)}>
                إضافة
              </button>
            )}
          </div>
        );
      })}
    </>
  );
}

export function CartPage({ goOrders }: { goOrders: () => void }) {
  const { cart, products, cartShop, cartTotals, changeQty, clearCart, placeOrder, profile } = useApp();
  const [name, setName] = useState(profile.name);
  const [phone, setPhone] = useState(profile.phone);
  const [address, setAddress] = useState(profile.address);
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [locMsg, setLocMsg] = useState('');
  const [busy, setBusy] = useState(false);

  if (cart.length === 0)
    return (
      <div className="empty">
        <div className="big">🛒</div>السلة فارغة
      </div>
    );

  const locate = async () => {
    setBusy(true);
    setLocMsg('');
    try {
      setPos(await getMyLocation());
    } catch {
      setLocMsg('تعذّر تحديد الموقع. تأكد من تفعيل GPS وإعطاء الإذن، أو اكتب العنوان يدوياً.');
    } finally {
      setBusy(false);
    }
  };

  const phoneOk = /^07\d{9}$/.test(phone.trim());
  const valid = name.trim().length > 1 && phoneOk && address.trim().length > 3;

  const submit = () => {
    if (!valid) return;
    const o = placeOrder({ name: name.trim(), phone: phone.trim(), address: address.trim(), lat: pos?.lat, lng: pos?.lng });
    if (o) goOrders();
  };

  return (
    <>
      <div className="row between">
        <div className="h2">سلة {cartShop?.name}</div>
        <button className="btn danger sm" onClick={clearCart}>
          تفريغ
        </button>
      </div>
      {cart.map((l) => {
        const p = products.find((x) => x.id === l.productId);
        if (!p) return null;
        return (
          <div key={l.productId} className="card row">
            <div className="emoji">{p.emoji}</div>
            <div className="grow">
              <div className="bold">{p.name}</div>
              <div className="muted small">{fmt(p.price)}</div>
            </div>
            <div className="qty">
              <button onClick={() => changeQty(l.productId, -1)}>−</button>
              <b>{l.qty}</b>
              <button onClick={() => changeQty(l.productId, 1)}>+</button>
            </div>
          </div>
        );
      })}

      <div className="card">
        <div className="bold" style={{ marginBottom: 8 }}>بيانات التوصيل</div>
        <label className="field">
          <span>الاسم</span>
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <label className="field">
          <span>رقم الهاتف (07XXXXXXXXX)</span>
          <input inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </label>
        {phone && !phoneOk && <div className="muted small" style={{ color: 'var(--danger)' }}>أدخل رقماً عراقياً صحيحاً من 11 رقم</div>}
        <label className="field">
          <span>العنوان (المنطقة، الشارع، أقرب نقطة دالة)</span>
          <textarea rows={2} value={address} onChange={(e) => setAddress(e.target.value)} />
        </label>
        <button className="btn ghost" onClick={locate} disabled={busy}>
          📍 {busy ? 'جارٍ التحديد…' : pos ? 'تحديث موقعي' : 'تحديد موقعي على الخريطة'}
        </button>
        {locMsg && <div className="muted small" style={{ marginTop: 6 }}>{locMsg}</div>}
        {pos && (
          <iframe
            className="map"
            title="موقعك"
            src={`https://www.openstreetmap.org/export/embed.html?bbox=${pos.lng - 0.004}%2C${pos.lat - 0.003}%2C${pos.lng + 0.004}%2C${pos.lat + 0.003}&layer=mapnik&marker=${pos.lat}%2C${pos.lng}`}
          />
        )}
      </div>

      <div className="card sum">
        <div><span>المنتجات</span><span>{fmt(cartTotals.subtotal)}</span></div>
        {cartTotals.discount > 0 && (
          <div><span>الخصم</span><span>− {fmt(cartTotals.discount)}</span></div>
        )}
        <div><span>رسوم التوصيل</span><span>{fmt(cartTotals.deliveryFee)}</span></div>
        <div className="total"><span>الإجمالي</span><span>{fmt(cartTotals.total)}</span></div>
        <div className="muted small" style={{ marginTop: 6 }}>💵 الدفع نقداً عند الاستلام (الدفع الإلكتروني لاحقاً)</div>
      </div>

      <button className="btn block" disabled={!valid} onClick={submit}>
        تأكيد الطلب (تجريبي)
      </button>
    </>
  );
}

export function OrdersPage() {
  const { orders, setOrderStatus, rateOrder } = useApp();
  if (orders.length === 0)
    return (
      <div className="empty">
        <div className="big">📦</div>لا توجد طلبات بعد
      </div>
    );
  return (
    <>
      {orders.map((o) => (
        <OrderCard
          key={o.id}
          order={o}
          showCustomer={false}
          actions={
            <>
              {o.status === 'new' && (
                <button className="btn danger sm" onClick={() => setOrderStatus(o.id, 'cancelled')}>
                  إلغاء الطلب
                </button>
              )}
              {o.status === 'delivered' && (
                <div className="stars row">
                  <span className="muted small">تقييمك:</span>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button key={n} className={(o.rating ?? 0) >= n ? 'on' : ''} onClick={() => rateOrder(o.id, n)}>
                      ★
                    </button>
                  ))}
                </div>
              )}
            </>
          }
        />
      ))}
    </>
  );
}
