-- مخطط قاعدة بيانات «وصّلني» لـ Supabase (للمرحلة الثانية).
-- شغّله من: Supabase > SQL Editor > New query > Run.
-- ملاحظة: لم يُجرَّب هذا المخطط على مشروع Supabase حقيقي بعد؛ راجعه قبل الاعتماد عليه.

create extension if not exists "pgcrypto";

create type user_role as enum ('customer', 'merchant', 'courier', 'admin');
create type order_status as enum ('new', 'accepted', 'preparing', 'on_the_way', 'delivered', 'cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role user_role not null default 'customer',
  full_name text,
  phone text,
  created_at timestamptz not null default now()
);

create table public.categories (
  id text primary key,
  name text not null,
  icon text
);

create table public.shops (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references public.profiles(id),
  category_id text references public.categories(id),
  city text not null default 'البصرة',
  name text not null,
  area text,
  phone text,
  delivery_fee integer not null default 0 check (delivery_fee >= 0),
  is_open boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  name text not null,
  description text,
  price integer not null check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  created_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  shop_id uuid not null references public.shops(id),
  courier_id uuid references public.profiles(id),
  status order_status not null default 'new',
  subtotal integer not null,
  discount integer not null default 0,
  delivery_fee integer not null,
  total integer not null,
  address text not null,
  lat double precision,
  lng double precision,
  customer_phone text not null,
  payment_method text not null default 'cash',
  rating smallint check (rating between 1 and 5),
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id),
  name text not null,
  price integer not null,
  qty integer not null check (qty > 0)
);

create table public.offers (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid references public.shops(id) on delete cascade,
  title text not null,
  discount_pct integer not null check (discount_pct between 1 and 90),
  is_active boolean not null default true
);

create table public.settings (
  key text primary key,
  value jsonb not null
);

-- دوال مساعدة (security definer لتجنب تكرار RLS)
create or replace function public.current_role_name() returns user_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.owns_shop(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.shops where id = sid and owner_id = auth.uid())
$$;

-- إنشاء ملف تعريف تلقائي عند التسجيل (الدور دائماً customer؛ الترقية يدوياً من المدير)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, role, full_name, phone)
  values (new.id, 'customer', new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone');
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- تفعيل RLS
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.shops enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.offers enable row level security;
alter table public.settings enable row level security;

-- profiles: كل مستخدم يرى ويعدّل ملفه (بدون تغيير الدور)، والمدير يرى الكل
create policy profiles_self_read on public.profiles for select
  using (id = auth.uid() or public.current_role_name() = 'admin');
create policy profiles_self_update on public.profiles for update
  using (id = auth.uid()) with check (id = auth.uid() and role = public.current_role_name());
create policy profiles_admin_all on public.profiles for all
  using (public.current_role_name() = 'admin') with check (public.current_role_name() = 'admin');

-- بيانات عامة للقراءة
create policy categories_read on public.categories for select using (true);
create policy categories_admin on public.categories for all
  using (public.current_role_name() = 'admin') with check (public.current_role_name() = 'admin');

create policy shops_read on public.shops for select using (true);
create policy shops_owner_update on public.shops for update
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy shops_admin on public.shops for all
  using (public.current_role_name() = 'admin') with check (public.current_role_name() = 'admin');

create policy products_read on public.products for select using (true);
create policy products_owner_write on public.products for all
  using (public.owns_shop(shop_id)) with check (public.owns_shop(shop_id));
create policy products_admin on public.products for all
  using (public.current_role_name() = 'admin') with check (public.current_role_name() = 'admin');

create policy offers_read on public.offers for select using (true);
create policy offers_admin on public.offers for all
  using (public.current_role_name() = 'admin') with check (public.current_role_name() = 'admin');

create policy settings_read on public.settings for select using (true);
create policy settings_admin on public.settings for all
  using (public.current_role_name() = 'admin') with check (public.current_role_name() = 'admin');

-- orders
create policy orders_customer_read on public.orders for select using (customer_id = auth.uid());
create policy orders_customer_insert on public.orders for insert
  with check (customer_id = auth.uid() and status = 'new' and courier_id is null);
create policy orders_merchant_read on public.orders for select using (public.owns_shop(shop_id));
create policy orders_merchant_update on public.orders for update
  using (public.owns_shop(shop_id)) with check (public.owns_shop(shop_id));
create policy orders_courier_read on public.orders for select
  using (
    public.current_role_name() = 'courier'
    and (courier_id = auth.uid() or (courier_id is null and status in ('accepted', 'preparing')))
  );
create policy orders_courier_update on public.orders for update
  using (public.current_role_name() = 'courier' and (courier_id = auth.uid() or courier_id is null))
  with check (public.current_role_name() = 'courier' and courier_id = auth.uid());
create policy orders_admin on public.orders for all
  using (public.current_role_name() = 'admin') with check (public.current_role_name() = 'admin');

-- order_items: تتبع صلاحيات الطلب الأب
create policy items_read on public.order_items for select using (
  exists (select 1 from public.orders o where o.id = order_id)
);
create policy items_customer_insert on public.order_items for insert with check (
  exists (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid())
);

-- Realtime لتحديث الطلبات
alter publication supabase_realtime add table public.orders;

-- تنبيه أمان: حدود تغيير الحقول (مثلاً منع المتجر من تعديل الأسعار بعد الإنشاء) تحتاج triggers
-- أو دوال RPC في المرحلة الثانية. الأعمدة الحساسة يجب ألا تُقبل من العميل بلا تحقق.
