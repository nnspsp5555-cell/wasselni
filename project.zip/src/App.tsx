import { useEffect, useState } from 'react';
import { useApp } from './store';
import { isSupabaseConfigured } from './lib/supabase';
import Login from './pages/Login';
import {
  CartPage,
  CategoryPage,
  Home,
  OrdersPage,
  ProductPage,
  ShopPage,
  type Route,
} from './pages/Customer';
import Logo from './components/Logo';
import Icon, { type IconName } from './components/Icon';
import Splash from './components/Splash';
import { categories } from './data/demo';
import { MerchantOrders, MerchantProducts } from './pages/Merchant';
import CourierTasks from './pages/Courier';
import { AdminDashboard, AdminOrders, AdminShops } from './pages/Admin';
import type { Role } from './types';

interface TabDef {
  id: string;
  icon: IconName;
  label: string;
}

const TABS: Record<Role, TabDef[]> = {
  customer: [
    { id: 'home', icon: 'home', label: 'الرئيسية' },
    { id: 'cart', icon: 'cart', label: 'السلة' },
    { id: 'orders', icon: 'orders', label: 'طلباتي' },
    { id: 'account', icon: 'user', label: 'حسابي' },
  ],
  merchant: [
    { id: 'orders', icon: 'inbox', label: 'الطلبات' },
    { id: 'products', icon: 'tag', label: 'المنتجات' },
    { id: 'account', icon: 'user', label: 'حسابي' },
  ],
  courier: [
    { id: 'tasks', icon: 'truck', label: 'المهام' },
    { id: 'account', icon: 'user', label: 'حسابي' },
  ],
  admin: [
    { id: 'dash', icon: 'chart', label: 'لوحة' },
    { id: 'orders', icon: 'orders', label: 'الطلبات' },
    { id: 'shops', icon: 'store', label: 'المتاجر' },
    { id: 'account', icon: 'user', label: 'حسابي' },
  ],
};

const ROLE_NAME: Record<Role, string> = {
  customer: 'زبون',
  merchant: 'متجر',
  courier: 'مندوب',
  admin: 'مدير',
};

function Account() {
  const { role, logout, resetDemo, seedDemoOrders } = useApp();
  return (
    <>
      <div className="card">
        <div className="bold">نوع الحساب: {role ? ROLE_NAME[role] : ''}</div>
        <div className="muted small" style={{ marginTop: 6 }}>
          وضع تجريبي: البيانات محفوظة على هذا الجهاز فقط.
          <br />
          {isSupabaseConfigured
            ? 'مفاتيح Supabase مضبوطة (الربط الكامل في المرحلة الثانية).'
            : 'Supabase غير مضبوط.'}
        </div>
      </div>
      <button className="btn block ghost" style={{ marginBottom: 10 }} onClick={seedDemoOrders}>
        إضافة طلبات تجريبية لمعاينة الشاشات
      </button>
      <button className="btn block ghost" style={{ marginBottom: 10 }} onClick={logout}>
        تبديل نوع الحساب
      </button>
      <button
        className="btn block danger"
        onClick={() => window.confirm('مسح كل البيانات التجريبية؟') && resetDemo()}
      >
        إعادة ضبط البيانات التجريبية
      </button>
    </>
  );
}

export default function App() {
  const { role, cartTotals, toasts, shops, shopId, products } = useApp();
  const [tab, setTab] = useState('');
  const [stack, setStack] = useState<Route[]>([{ name: 'home' }]);
  const [splash, setSplash] = useState(true);
  const route = stack[stack.length - 1];

  const go = (r: Route) => setStack((st) => [...st, r]);
  const back = () => setStack((st) => (st.length > 1 ? st.slice(0, -1) : st));
  const resetNav = () => setStack([{ name: 'home' }]);

  // عند تغيير الدور نعود إلى أول تبويب
  useEffect(() => {
    setTab(role ? TABS[role][0].id : '');
    resetNav();
  }, [role]);

  if (splash) return <Splash onDone={() => setSplash(false)} />;
  if (!role) return <Login />;

  const tabs = TABS[role];
  const shopName = shops.find((s) => s.id === shopId)?.name;
  const inHome = role === 'customer' && tab === 'home';
  let title = tabs.find((t) => t.id === tab)?.label ?? 'وصّلني';
  if (inHome && route.name === 'category') title = categories.find((c) => c.id === route.id)?.short ?? 'القسم';
  if (inHome && route.name === 'shop') title = shops.find((x) => x.id === route.id)?.name ?? 'المتجر';
  if (inHome && route.name === 'product') title = products.find((x) => x.id === route.id)?.name ?? 'المنتج';

  let body: JSX.Element | null = null;
  if (role === 'customer') {
    if (tab === 'home') {
      if (route.name === 'category') body = <CategoryPage id={route.id} go={go} />;
      else if (route.name === 'shop') body = <ShopPage shopId={route.id} go={go} />;
      else if (route.name === 'product') body = <ProductPage id={route.id} go={go} />;
      else body = <Home go={go} />;
    } else if (tab === 'cart') body = <CartPage goOrders={() => setTab('orders')} />;
    else if (tab === 'orders') body = <OrdersPage />;
  } else if (role === 'merchant') {
    if (tab === 'orders') body = <MerchantOrders />;
    else if (tab === 'products') body = <MerchantProducts />;
  } else if (role === 'courier') {
    if (tab === 'tasks') body = <CourierTasks />;
  } else if (role === 'admin') {
    if (tab === 'dash') body = <AdminDashboard />;
    else if (tab === 'orders') body = <AdminOrders />;
    else if (tab === 'shops') body = <AdminShops />;
  }
  if (tab === 'account') body = <Account />;

  return (
    <div className="app">
      <div className="topbar">
        <div className="row" style={{ minWidth: 0 }}>
          {inHome && route.name === 'home' ? (
            <Logo size={38} withName light />
          ) : (
            <div>
              <h1>{title}</h1>
              <div className="sub">
                وصّلني · البصرة{role === 'merchant' && shopName ? ` · ${shopName}` : ''} · نسخة تجريبية
              </div>
            </div>
          )}
        </div>
        {inHome && route.name !== 'home' ? (
          <button className="back" onClick={back}>
            رجوع ›
          </button>
        ) : (
          <span className="demo-pill">تجريبي</span>
        )}
      </div>

      <div className="toasts">
        {toasts.map((t) => (
          <div key={t.id} className="toast">
            <Icon name="bell" size={16} /> {t.text}
          </div>
        ))}
      </div>

      <div className="content">{body}</div>

      <nav className="tabbar">
        {tabs.map((t) => (
          <button
            key={t.id}
            className={`tab ${tab === t.id ? 'active' : ''}`}
            onClick={() => {
              if (t.id === 'home' && tab === 'home') resetNav();
              setTab(t.id);
            }}
          >
            <span className="ic"><Icon name={t.icon} size={22} stroke={tab === t.id ? 2.1 : 1.7} /></span>
            {t.label}
            {role === 'customer' && t.id === 'cart' && cartTotals.count > 0 && (
              <span className="badge">{cartTotals.count}</span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
}
