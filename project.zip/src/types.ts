export type Role = 'customer' | 'merchant' | 'courier' | 'admin';

export type OrderStatus =
  | 'new'
  | 'accepted'
  | 'preparing'
  | 'on_the_way'
  | 'delivered'
  | 'cancelled';

export interface Category {
  id: string;
  name: string;
  icon: string;
}

export interface Shop {
  id: string;
  name: string;
  categoryId: string;
  rating: number;
  etaMin: number;
  deliveryFee: number;
  emoji: string;
  area: string;
  open: boolean;
  phone: string;
}

export interface Product {
  id: string;
  shopId: string;
  name: string;
  price: number;
  stock: number;
  emoji: string;
  desc: string;
}

export interface Offer {
  id: string;
  title: string;
  desc: string;
  shopId: string;
  discountPct: number;
  active: boolean;
}

export interface CartLine {
  productId: string;
  qty: number;
}

export interface OrderLine {
  productId: string;
  name: string;
  price: number;
  qty: number;
}

export interface Order {
  id: string;
  shopId: string;
  lines: OrderLine[];
  subtotal: number;
  discount: number;
  deliveryFee: number;
  total: number;
  status: OrderStatus;
  address: string;
  lat?: number;
  lng?: number;
  customerName: string;
  customerPhone: string;
  courierId?: string;
  createdAt: number;
  payment: 'cash';
  rating?: number;
}

export interface Settings {
  commissionPct: number;
  city: string;
}

export interface Courier {
  id: string;
  name: string;
  phone: string;
}

export interface Toast {
  id: number;
  text: string;
}
