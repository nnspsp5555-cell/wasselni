import { Geolocation } from '@capacitor/geolocation';

export interface Pos {
  lat: number;
  lng: number;
}

export async function getMyLocation(): Promise<Pos> {
  try {
    await Geolocation.requestPermissions();
  } catch {
    /* على المتصفح قد لا تتوفر؛ نكمل */
  }
  const p = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 15000 });
  return { lat: p.coords.latitude, lng: p.coords.longitude };
}
